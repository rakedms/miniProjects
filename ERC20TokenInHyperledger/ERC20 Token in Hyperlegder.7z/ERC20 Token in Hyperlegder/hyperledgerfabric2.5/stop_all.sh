#!/bin/bash

./stop_ca.sh 

./stop_network.sh