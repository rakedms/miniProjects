let express = require("express");
let bodyParser = require("body-parser");

let app = express();


const { Gateway, Wallets } = require("fabric-network");
const path = require("path");
const fs = require("fs");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.post("/api/blockchain/initialize/:issuerId", async function (req,res) {
  try{
    const {issuerId} = req.params
    const {name, symbol, decimals} = req.body;
    console.log(18, issuerId, name, symbol, decimals)
    // const issuer = await issuerModel.findOne(issuerId);

    // if (!issuer){
    //     res.status(404).send({status: false, message :"Issuer not found"})
    // }

    const parentDir = path.resolve(__dirname, '..');
    const issuerDir = path.join(parentDir, 'issuer');
    const ccpPath = path.join(issuerDir, 'connection-issuer.json');
    
    // Read the content of the connection-issuer.json file
    const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf-8'));

    const walletPath = path.join(issuerDir, 'walletIssuer');
    const wallet = await Wallets.newFileSystemWallet(walletPath);

    try {
      const identity = await wallet.get(issuerId);
      console.log(identity);
      if (!identity) {
        console.log(
          `An identity for the user "${issuerId}" does not exist in the wallet`
        );
        console.log(
          "Run the registerUser.js application before retrying"
        );
        throw new Error(
          `An identity for the user ${username.toUpperCase()} does not exist in the wallet`
        );
      }
    } catch (err) {
      console.log(err.message);
    }

    try {
        const gateway = new Gateway();
        await gateway.connect(ccp, {
          wallet,
          identity: issuerId,
          discovery: {
            enabled: true,
            asLocalhost: true,
          },
        });

        const network = await gateway.getNetwork("asset-channel");
        const contract = network.getContract("assetcode");

        var bctransaction = await contract.createTransaction("Initialize");

        let result = await bctransaction.submit(name,symbol, decimals)
        var txID = bctransaction.getTransactionId();

        console.log(result.toString())

        await gateway.disconnect();
        console.log("Transaction has been submitted");
        return res.status(201).send({
          status: true,
          message: "Transaction has been submitted",
          response:  JSON.parse(result.toString()),
          txID
        });
            }
    catch(error){
    console.log("Failed at", error)
    return res.status(500).json({status:false, message: error.message})
    }

}catch(error){
    console.log(error)
    return res.status(500).json({status:false, message: error.message})
    
}

})

app.post("/api/blockchain/mint/:issuerId", async function (req,res) {
  try{
    const {issuerId} = req.params
    const {amt} = req.body;
    console.log(100, issuerId, amt)
    // const issuer = await issuerModel.findOne(issuerId);

    // if (!issuer){
    //     res.status(404).send({status: false, message :"Issuer not found"})
    // }

    const parentDir = path.resolve(__dirname, '..');
    const issuerDir = path.join(parentDir, 'issuer');
    const ccpPath = path.join(issuerDir, 'connection-issuer.json');
    
    // Read the content of the connection-issuer.json file
    const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf-8'));

    const walletPath = path.join(issuerDir, 'walletIssuer');
    const wallet = await Wallets.newFileSystemWallet(walletPath);

    try {
      const identity = await wallet.get(issuerId);
      console.log(identity);
      if (!identity) {
        console.log(
          `An identity for the user "${issuerId}" does not exist in the wallet`
        );
        console.log(
          "Run the registerUser.js application before retrying"
        );
        throw new Error(
          `An identity for the user ${username.toUpperCase()} does not exist in the wallet`
        );
      }
    } catch (err) {
      console.log(err.message);
    }

    try {
        const gateway = new Gateway();
        await gateway.connect(ccp, {
          wallet,
          identity: issuerId,
          discovery: {
            enabled: true,
            asLocalhost: true,
          },
        });

        const network = await gateway.getNetwork("asset-channel");
        const contract = network.getContract("assetcode");

        var bctransaction = await contract.createTransaction("Mint", amt);

        let result = await bctransaction.submit(amt)
        var txID = bctransaction.getTransactionId();
        console.log(result.toString())

        await gateway.disconnect();
        console.log("Transaction has been submitted");
        return res.status(201).send({
          status: true,
          message: "Transaction has been submitted",
          response:  JSON.parse(result.toString()),
          txID
        });
            }
    catch(error){
    console.log("Failed at", error)
    return res.status(500).json({status:false, message: error.message})
    }

  }catch(error){
    console.log(error)
    return res.status(500).json({status:false, message: error.message})
  }

})

app.post("/api/blockchain/burn/:issuerId", async function (req,res) {
  try{
    const {issuerId} = req.params
    const {amt} = req.body;
    console.log(180, issuerId, amt)
    // const issuer = await issuerModel.findOne(issuerId);

    // if (!issuer){
    //     res.status(404).send({status: false, message :"Issuer not found"})
    // }

    const parentDir = path.resolve(__dirname, '..');
    const issuerDir = path.join(parentDir, 'issuer');
    const ccpPath = path.join(issuerDir, 'connection-issuer.json');
    
    // Read the content of the connection-issuer.json file
    const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf-8'));

    const walletPath = path.join(issuerDir, 'walletIssuer');
    const wallet = await Wallets.newFileSystemWallet(walletPath);

    try {
      const identity = await wallet.get(issuerId);
      console.log(identity);
      if (!identity) {
        console.log(
          `An identity for the user "${issuerId}" does not exist in the wallet`
        );
        console.log(
          "Run the registerUser.js application before retrying"
        );
        throw new Error(
          `An identity for the user ${username.toUpperCase()} does not exist in the wallet`
        );
      }
    } catch (err) {
      console.log(err.message);
    }

    try {
        const gateway = new Gateway();
        await gateway.connect(ccp, {
          wallet,
          identity: issuerId,
          discovery: {
            enabled: true,
            asLocalhost: true,
          },
        });

        const network = await gateway.getNetwork("asset-channel");
        const contract = network.getContract("assetcode");

        var bctransaction = await contract.createTransaction("Burn", amt);

        let result = await bctransaction.submit(amt)
        var txID = bctransaction.getTransactionId();
        console.log(result.toString())

        await gateway.disconnect();
        console.log("Transaction has been submitted");
        return res.status(201).send({
          status: true,
          message: "Transaction has been submitted",
          response:  JSON.parse(result.toString()),
          txID
        });
            }
    catch(error){
    console.log("Failed at", error)
    return res.status(500).json({status:false, message: error.message})
    }

  }catch(error){
    console.log(error)
    return res.status(500).json({status:false, message: error.message})
  }

})

app.put("/api/blockchain/transfer/:issuerId", async function (req,res) {
  try{
    const {issuerId} = req.params
    const {recipient,amt} = req.body;
    console.log(260, issuerId, recipient,amt)

    // const issuer = await issuerModel.findOne(issuerId);

    // if (!issuer){
    //     res.status(404).send({status: false, message :"Issuer not found"})
    // }

    const parentDir = path.resolve(__dirname, '..');
    const issuerDir = path.join(parentDir, 'issuer');
    const ccpPath = path.join(issuerDir, 'connection-issuer.json');
    
    // Read the content of the connection-issuer.json file
    const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf-8'));

    const walletPath = path.join(issuerDir, 'walletIssuer');
    const wallet = await Wallets.newFileSystemWallet(walletPath);

    try {
      const identity = await wallet.get(issuerId);
      console.log(identity);
      if (!identity) {
        console.log(
          `An identity for the user "${issuerId}" does not exist in the wallet`
        );
        console.log(
          "Run the registerUser.js application before retrying"
        );
        throw new Error(
          `An identity for the user ${username.toUpperCase()} does not exist in the wallet`
        );
      }
    } catch (err) {
      console.log(err.message);
    }

    try {
        const gateway = new Gateway();
        await gateway.connect(ccp, {
          wallet,
          identity: issuerId,
          discovery: {
            enabled: true,
            asLocalhost: true,
          },
        });

        const network = await gateway.getNetwork("asset-channel");
        const contract = network.getContract("assetcode");

        var bctransaction = await contract.createTransaction("Transfer", recipient, amt);

        let result = await bctransaction.submit(amt)
        var txID = bctransaction.getTransactionId();

        console.log(result.toString())

        await gateway.disconnect();
        console.log("Transaction has been submitted");
        return res.status(201).send({
          status: true,
          message: "Transaction has been submitted",
          response:  JSON.parse(result.toString()),
          txID
        });
            }
    catch(error){
    console.log("Failed at", error)
    return res.status(500).json({status:false, message: error.message})
    }

  }catch(error){
    console.log(error)
    return res.status(500).json({status:false, message: error.message})
  }

})

app.get("/api/blockchain/balanceOf/:issuerId", async function (req,res) {
  try{
    const {issuerId} = req.params;
    const{accountId} = req.body;
    console.log(342, issuerId, accountId)
    // const issuer = await issuerModel.findOne(issuerId);

    // if (!issuer){
    //     res.status(404).send({status: false, message :"Issuer not found"})
    // }

    const parentDir = path.resolve(__dirname, '..');
    const issuerDir = path.join(parentDir, 'issuer');
    const ccpPath = path.join(issuerDir, 'connection-issuer.json');
    
    // Read the content of the connection-issuer.json file
    const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf-8'));

    const walletPath = path.join(issuerDir, 'walletIssuer');
    const wallet = await Wallets.newFileSystemWallet(walletPath);

    try {
      const identity = await wallet.get(issuerId);
      console.log(identity);
      if (!identity) {
        console.log(
          `An identity for the user "${issuerId}" does not exist in the wallet`
        );
        console.log(
          "Run the registerUser.js application before retrying"
        );
        throw new Error(
          `An identity for the user ${username.toUpperCase()} does not exist in the wallet`
        );
        return;
      }
    } catch (err) {
      console.log(err.message);
    }

    try {
        const gateway = new Gateway();
        await gateway.connect(ccp, {
          wallet,
          identity: issuerId,
          discovery: {
            enabled: true,
            asLocalhost: true,
          },
        });

        const network = await gateway.getNetwork("asset-channel");
        const contract = network.getContract("assetcode");

        var result = await contract.evaluateTransaction("BalanceOf", accountId);

        // var txID = bctransaction.getTransactionId();
        console.log(result)

        await gateway.disconnect();
        console.log("Balance have been fetched");
        return res.status(201).send({
          status: true,
          message: "Balance have been fetched",
          response:  JSON.parse(result.toString()),
        });
        }
    catch(error){
    console.log("Failed at", error)
    return res.status(500).json({status:false, message: error.message})
    }

  }catch(error){
    console.log(error)
    return res.status(500).json({status:false, message: error.message})
  }

})

app.get("/api/blockchain/getClientAccountBalance/:issuerId", async function (req,res) {
  try{
    const {issuerId} = req.params;
    console.log(420, issuerId)
    // const issuer = await issuerModel.findOne(issuerId);

    // if (!issuer){
    //     res.status(404).send({status: false, message :"Issuer not found"})
    // }

    const parentDir = path.resolve(__dirname, '..');
    const issuerDir = path.join(parentDir, 'issuer');
    const ccpPath = path.join(issuerDir, 'connection-issuer.json');
    
    // Read the content of the connection-issuer.json file
    const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf-8'));

    const walletPath = path.join(issuerDir, 'walletIssuer');
    const wallet = await Wallets.newFileSystemWallet(walletPath);

    try {
      const identity = await wallet.get(issuerId);
      console.log(identity);
      if (!identity) {
        console.log(
          `An identity for the user "${issuerId}" does not exist in the wallet`
        );
        console.log(
          "Run the registerUser.js application before retrying"
        );
        throw new Error(
          `An identity for the user ${username.toUpperCase()} does not exist in the wallet`
        );
        return;
      }
    } catch (err) {
      console.log(err.message);
    }

    try {
        const gateway = new Gateway();
        await gateway.connect(ccp, {
          wallet,
          identity: issuerId,
          discovery: {
            enabled: true,
            asLocalhost: true,
          },
        });

        const network = await gateway.getNetwork("asset-channel");
        const contract = network.getContract("assetcode");

        var result = await contract.evaluateTransaction("ClientAccountBalance");

        // var txID = bctransaction.getTransactionId();

        console.log(result)

        await gateway.disconnect();
       
        return res.status(201).send({
          status: true,
          message: "Client account balance have been fetched",
          response:  JSON.parse(result.toString()),
        });
        }
    catch(error){
    console.log("Failed at", error)
    return res.status(500).json({status:false, message: error.message})
    }

  }catch(error){
    console.log(error)
    return res.status(500).json({status:false, message: error.message})
  }

})

app.get("/api/blockchain/getClientID/:issuerId", async function (req,res) {
  try{
    const {issuerId} = req.params;
    console.log(341, issuerId)
    // const issuer = await issuerModel.findOne(issuerId);

    // if (!issuer){
    //     res.status(404).send({status: false, message :"Issuer not found"})
    // }

    const parentDir = path.resolve(__dirname, '..');
    const issuerDir = path.join(parentDir, 'issuer');
    const ccpPath = path.join(issuerDir, 'connection-issuer.json');
    
    // Read the content of the connection-issuer.json file
    const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf-8'));

    const walletPath = path.join(issuerDir, 'walletIssuer');
    const wallet = await Wallets.newFileSystemWallet(walletPath);

    try {
      const identity = await wallet.get(issuerId);
      console.log(identity);
      if (!identity) {
        console.log(
          `An identity for the user "${issuerId}" does not exist in the wallet`
        );
        console.log(
          "Run the registerUser.js application before retrying"
        );
        throw new Error(
          `An identity for the user ${username.toUpperCase()} does not exist in the wallet`
        );
        return;
      }
    } catch (err) {
      console.log(err.message);
    }

    try {
        const gateway = new Gateway();
        await gateway.connect(ccp, {
          wallet,
          identity: issuerId,
          discovery: {
            enabled: true,
            asLocalhost: true,
          },
        });

        const network = await gateway.getNetwork("asset-channel");
        const contract = network.getContract("assetcode");

        var result = await contract.evaluateTransaction("ClientAccountID");

        // var txID = bctransaction.getTransactionId();
        const buffer = Buffer.from(result);
        const clientId = buffer.toString('utf-8');

        console.log(clientId)

        await gateway.disconnect();
       
        return res.status(201).send({
          status: true,
          message: "ClientId have been fetched",
          clientId
        });
        }
    catch(error){
    console.log("Failed at", error)
    return res.status(500).json({status:false, message: error.message})
    }

  }catch(error){
    console.log(error)
    return res.status(500).json({status:false, message: error.message})
  }

})

app.get("/api/blockchain/getTotalSupply/:issuerId", async function (req,res) {
  try{
    const {issuerId} = req.params;
    console.log(580, issuerId)
    // const issuer = await issuerModel.findOne(issuerId);

    // if (!issuer){
    //     res.status(404).send({status: false, message :"Issuer not found"})
    // }

    const parentDir = path.resolve(__dirname, '..');
    const issuerDir = path.join(parentDir, 'issuer');
    const ccpPath = path.join(issuerDir, 'connection-issuer.json');
    
    // Read the content of the connection-issuer.json file
    const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf-8'));

    const walletPath = path.join(issuerDir, 'walletIssuer');
    const wallet = await Wallets.newFileSystemWallet(walletPath);

    try {
      const identity = await wallet.get(issuerId);
      console.log(identity);
      if (!identity) {
        console.log(
          `An identity for the user "${issuerId}" does not exist in the wallet`
        );
        console.log(
          "Run the registerUser.js application before retrying"
        );
        throw new Error(
          `An identity for the user ${username.toUpperCase()} does not exist in the wallet`
        );
        return;
      }
    } catch (err) {
      console.log(err.message);
    }

    try {
        const gateway = new Gateway();
        await gateway.connect(ccp, {
          wallet,
          identity: issuerId,
          discovery: {
            enabled: true,
            asLocalhost: true,
          },
        });

        const network = await gateway.getNetwork("asset-channel");
        const contract = network.getContract("assetcode");

        var result = await contract.evaluateTransaction("TotalSupply");

        // var txID = bctransaction.getTransactionId();

        console.log(result)

        await gateway.disconnect();
       
        return res.status(201).send({
          status: true,
          message: "Client account balance have been fetched",
          response:  JSON.parse(result.toString()),
        });
        }
    catch(error){
    console.log("Failed at", error)
    return res.status(500).json({status:false, message: error.message})
    }

  }catch(error){
    console.log(error)
    return res.status(500).json({status:false, message: error.message})
  }

})

app.post("/api/blockchain/approve/:issuerId", async function (req,res) {
  try{
    const {issuerId} = req.params
    const {spenderAccount, amt} = req.body;
    console.log(660, issuerId, spender, amt)
    // const issuer = await issuerModel.findOne(issuerId);

    // if (!issuer){
    //     res.status(404).send({status: false, message :"Issuer not found"})
    // }

    const parentDir = path.resolve(__dirname, '..');
    const issuerDir = path.join(parentDir, 'issuer');
    const ccpPath = path.join(issuerDir, 'connection-issuer.json');
    
    // Read the content of the connection-issuer.json file
    const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf-8'));

    const walletPath = path.join(issuerDir, 'walletIssuer');
    const wallet = await Wallets.newFileSystemWallet(walletPath);

    try {
      const identity = await wallet.get(issuerId);
      console.log(identity);
      if (!identity) {
        console.log(
          `An identity for the user "${issuerId}" does not exist in the wallet`
        );
        console.log(
          "Run the registerUser.js application before retrying"
        );
        throw new Error(
          `An identity for the user ${username.toUpperCase()} does not exist in the wallet`
        );
      }
    } catch (err) {
      console.log(err.message);
    }

    try {
        const gateway = new Gateway();
        await gateway.connect(ccp, {
          wallet,
          identity: issuerId,
          discovery: {
            enabled: true,
            asLocalhost: true,
          },
        });

        const network = await gateway.getNetwork("asset-channel");
        const contract = network.getContract("assetcode");

        var bctransaction = await contract.createTransaction("Approve", spenderAccount, amt);

        let result = await bctransaction.submit(amt)
        var txID = bctransaction.getTransactionId();
        console.log(result.toString())

        await gateway.disconnect();
        console.log("Transaction has been submitted");
        return res.status(201).send({
          status: true,
          message: "Transaction has been submitted",
          response:  JSON.parse(result.toString()),
          txID
        });
            }
    catch(error){
    console.log("Failed at", error)
    return res.status(500).json({status:false, message: error.message})
    }

  }catch(error){
    console.log(error)
    return res.status(500).json({status:false, message: error.message})
  }

})

app.get("/api/blockchain/allowance/:issuerId", async function (req,res) {
  try{
    const {issuerId} = req.params;
    const{ownerAccount, spenderAccount} = req.body;
    console.log(342, ownerAccount, spenderAccount)
    // const issuer = await issuerModel.findOne(issuerId);

    // if (!issuer){
    //     res.status(404).send({status: false, message :"Issuer not found"})
    // }

    const parentDir = path.resolve(__dirname, '..');
    const issuerDir = path.join(parentDir, 'issuer');
    const ccpPath = path.join(issuerDir, 'connection-issuer.json');
    
    // Read the content of the connection-issuer.json file
    const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf-8'));

    const walletPath = path.join(issuerDir, 'walletIssuer');
    const wallet = await Wallets.newFileSystemWallet(walletPath);

    try {
      const identity = await wallet.get(issuerId);
      console.log(identity);
      if (!identity) {
        console.log(
          `An identity for the user "${issuerId}" does not exist in the wallet`
        );
        console.log(
          "Run the registerUser.js application before retrying"
        );
        throw new Error(
          `An identity for the user ${username.toUpperCase()} does not exist in the wallet`
        );
        return;
      }
    } catch (err) {
      console.log(err.message);
    }

    try {
        const gateway = new Gateway();
        await gateway.connect(ccp, {
          wallet,
          identity: issuerId,
          discovery: {
            enabled: true,
            asLocalhost: true,
          },
        });

        const network = await gateway.getNetwork("asset-channel");
        const contract = network.getContract("assetcode");

        var result = await contract.evaluateTransaction("Allowance", ownerAccount, spenderAccount);

        // var txID = bctransaction.getTransactionId();
        console.log(result)

        await gateway.disconnect();
        console.log("Balance have been fetched");
        return res.status(201).send({
          status: true,
          message: "Allowance has been fetched",
          response:  JSON.parse(result.toString()),
        });
        }
    catch(error){
    console.log("Failed at", error)
    return res.status(500).json({status:false, message: error.message})
    }

  }catch(error){
    console.log(error)
    return res.status(500).json({status:false, message: error.message})
  }

})

app.put("/api/blockchain/transferFrom/:issuerId", async function (req,res) {
  try{
    const {issuerId} = req.params
    const {OwnerAccount, RecipientAccount} = req.body;
    console.log(260, issuerId, OwnerAccount,RecipientAccount)

    // const issuer = await issuerModel.findOne(issuerId);

    // if (!issuer){
    //     res.status(404).send({status: false, message :"Issuer not found"})
    // }

    const parentDir = path.resolve(__dirname, '..');
    const issuerDir = path.join(parentDir, 'issuer');
    const ccpPath = path.join(issuerDir, 'connection-issuer.json');
    
    // Read the content of the connection-issuer.json file
    const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf-8'));

    const walletPath = path.join(issuerDir, 'walletIssuer');
    const wallet = await Wallets.newFileSystemWallet(walletPath);

    try {
      const identity = await wallet.get(issuerId);
      console.log(identity);
      if (!identity) {
        console.log(
          `An identity for the user "${issuerId}" does not exist in the wallet`
        );
        console.log(
          "Run the registerUser.js application before retrying"
        );
        throw new Error(
          `An identity for the user ${username.toUpperCase()} does not exist in the wallet`
        );
      }
    } catch (err) {
      console.log(err.message);
    }

    try {
        const gateway = new Gateway();
        await gateway.connect(ccp, {
          wallet,
          identity: issuerId,
          discovery: {
            enabled: true,
            asLocalhost: true,
          },
        });

        const network = await gateway.getNetwork("asset-channel");
        const contract = network.getContract("assetcode");

        var bctransaction = await contract.createTransaction("TransferFrom", OwnerAccount, RecipientAccount);

        let result = await bctransaction.submit(amt)
        var txID = bctransaction.getTransactionId();

        console.log(result.toString())

        await gateway.disconnect();
        console.log("Transaction has been submitted");
        return res.status(201).send({
          status: true,
          message: "Transaction has been submitted",
          response:  JSON.parse(result.toString()),
          txID
        });
            }
    catch(error){
    console.log("Failed at", error)
    return res.status(500).json({status:false, message: error.message})
    }

  }catch(error){
    console.log(error)
    return res.status(500).json({status:false, message: error.message})
  }

})

app.get("/api/blockchain/getTokenName/:issuerId", async function (req,res) {
  try{
    const {issuerId} = req.params;
    console.log(900, issuerId)
    // const issuer = await issuerModel.findOne(issuerId);

    // if (!issuer){
    //     res.status(404).send({status: false, message :"Issuer not found"})
    // }

    const parentDir = path.resolve(__dirname, '..');
    const issuerDir = path.join(parentDir, 'issuer');
    const ccpPath = path.join(issuerDir, 'connection-issuer.json');
    
    // Read the content of the connection-issuer.json file
    const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf-8'));

    const walletPath = path.join(issuerDir, 'walletIssuer');
    const wallet = await Wallets.newFileSystemWallet(walletPath);

    try {
      const identity = await wallet.get(issuerId);
      console.log(identity);
      if (!identity) {
        console.log(
          `An identity for the user "${issuerId}" does not exist in the wallet`
        );
        console.log(
          "Run the registerUser.js application before retrying"
        );
        throw new Error(
          `An identity for the user ${username.toUpperCase()} does not exist in the wallet`
        );
      }
    } catch (err) {
      console.log(err.message);
    }

    try {
        const gateway = new Gateway();
        await gateway.connect(ccp, {
          wallet,
          identity: issuerId,
          discovery: {
            enabled: true,
            asLocalhost: true,
          },
        });

        const network = await gateway.getNetwork("asset-channel");
        const contract = network.getContract("assetcode");

        var result = await contract.evaluateTransaction("Name");

        // var txID = bctransaction.getTransactionId();
        console.log(result)

        await gateway.disconnect();
        console.log("Balance have been fetched");
        return res.status(201).send({
          status: true,
          message: "Token Name have been fetched",
          response:  JSON.parse(result.toString()),
        });
        }
    catch(error){
    console.log("Failed at", error)
    return res.status(500).json({status:false, message: error.message})
    }

  }catch(error){
    console.log(error)
    return res.status(500).json({status:false, message: error.message})
  }

})

app.get("/api/blockchain/getTokenSymbol/:issuerId", async function (req,res) {
  try{
    const {issuerId} = req.params;
    console.log(977, issuerId)
    // const issuer = await issuerModel.findOne(issuerId);

    // if (!issuer){
    //     res.status(404).send({status: false, message :"Issuer not found"})
    // }

    const parentDir = path.resolve(__dirname, '..');
    const issuerDir = path.join(parentDir, 'issuer');
    const ccpPath = path.join(issuerDir, 'connection-issuer.json');
    
    // Read the content of the connection-issuer.json file
    const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf-8'));

    const walletPath = path.join(issuerDir, 'walletIssuer');
    const wallet = await Wallets.newFileSystemWallet(walletPath);

    try {
      const identity = await wallet.get(issuerId);
      console.log(identity);
      if (!identity) {
        console.log(
          `An identity for the user "${issuerId}" does not exist in the wallet`
        );
        console.log(
          "Run the registerUser.js application before retrying"
        );
        throw new Error(
          `An identity for the user ${username.toUpperCase()} does not exist in the wallet`
        );
      }
    } catch (err) {
      console.log(err.message);
    }

    try {
        const gateway = new Gateway();
        await gateway.connect(ccp, {
          wallet,
          identity: issuerId,
          discovery: {
            enabled: true,
            asLocalhost: true,
          },
        });

        const network = await gateway.getNetwork("asset-channel");
        const contract = network.getContract("assetcode");

        var result = await contract.evaluateTransaction("Symbol");

        // var txID = bctransaction.getTransactionId();
        console.log(result)

        await gateway.disconnect();
        console.log("Balance have been fetched");
        return res.status(201).send({
          status: true,
          message: "Token Symbol have been fetched",
          response:  JSON.parse(result.toString()),
        });
        }
    catch(error){
    console.log("Failed at", error)
    return res.status(500).json({status:false, message: error.message})
    }

  }catch(error){
    console.log(error)
    return res.status(500).json({status:false, message: error.message})
  }

})



app.listen(8088, () => {
  console.log("Issuer running on http://localhost:8088");
});  

