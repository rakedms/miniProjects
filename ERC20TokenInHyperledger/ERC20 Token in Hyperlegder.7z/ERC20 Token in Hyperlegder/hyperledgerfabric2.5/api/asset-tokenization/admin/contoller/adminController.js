const bcrypt = require("bcrypt");
const adminModel = require("../models/adminModel");
const { registerEnroll } = require("../registerEnrollClientUserRegistry");
const { JWT } = require("../configs/config");
const jwt = require("jsonwebtoken");
const ipfsUtilFun = require("../utils/ipfs");
const { Gateway, Wallets } = require("fabric-network");
const path = require("path");
const fs = require("fs");
const mongoose = require("mongoose");
const uuid = require("uuid");
const registryId = require("../models/registryId.js");
const axios = require("axios");
const randomString = require("randomstring");
const {
  forgotPasswordMail,
  resetPasswordMail,
  welcomMail,
} = require("../utils/mailService.js");
const verificationModel = require("../models/verificationModel.js");
const { generatePassword } = require("../utils/utils.js");
const { Console } = require("console");
const issuerModel = require("../models/issuerModel.js");


const login = async function (req, res) {
  try {
    const { username, password } = req.body;

    if (!username) {
      return res
        .status(400)
        .send({ status: false, message: "Username is required" });
    }
    if (!password) {
      return res
        .status(400)
        .send({ status: false, message: "Password is required" });
    }

    const user = await userModel.findOne({
      $or: [
        { username: username.toLowerCase() },
        { email: username.toLowerCase() },
      ],
    });
    if (!user) {
      return res
        .status(404)
        .send({ status: false, message: "Invalid Username!" });
    }
    let match = await bcrypt.compare(password, user.coded_password);
    if (!match) {
      return res
        .status(400)
        .send({ status: false, message: "Password is Incorrect" });
    }

    let access_token = jwt.sign(
      {
        user_id: user._id,
        email: user.email,
        username: user.username,
      },
      JWT.access_key,
      { expiresIn: JWT.access_expiry }
    );

    let refresh_token = jwt.sign(
      {
        user_id: user._id,
        email: user.email,
        username: user.username,
      },
      JWT.refresh_key,
      { expiresIn: JWT.refresh_expiry }
    );

    return res.status(200).send({
      Status: true,
      message: "User Login successfull",
      data: user,
      access_token: access_token,
      refresh_token: refresh_token,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ status: false, Error: error.message });
  }
};

const generateToken = async (req, res) => {
  try {
    const { user_id } = req.token;
    let access_token;
    let user = await userModel.findOne({ _id: user_id });
    if (!user) {
      // user = await shareHolderModel.findOne({ _id: user_id });
      // if (!user) {
      //   return res
      //     .status(404)
      //     .send({ status: false, message: "User not found" });
      // }
      // access_token = jwt.sign(
      //   {
      //     user_id: user._id,
      //     email: user.mail_address,
      //     username: user.shareHolder_name,
      //   },
      //   JWT.access_key,
      //   { expiresIn: JWT.access_expiry }
      // );
      return res.status(404).send({status:false, message:"User not found"})
    }

    access_token = jwt.sign(
      {
        user_id: user._id,
        email: user.email,
        username: user.username,
      },
      JWT.access_key,
      { expiresIn: JWT.access_expiry }
    );

    return res.status(200).send({
      status: true,
      message: "Token Generated Successfully",
      data: { access_token: access_token },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ status: false, message: error.message });
  }
};

const onboardCompany = async function (req, res) {
  try {
    const { userId } = req.params;
    const {
      company_name,
      company_registration_date,
      company_bank,
      dt_company_activity,
      dt_company_facility,
      company_legal_status,
      share_capital,
    } = req.body;
    let obj = {};
    obj.onboarded_by = userId;
    if (!company_name) {
      return res
        .status(400)
        .send({ status: false, message: "Company name is required" });
    }
    const companyNameExist = await companyModel.findOne({
      company_name: company_name,
    });
    if (companyNameExist) {
      return res.status(409).send({
        status: false,
        message: "Company Name already exist",
      });
    }
    obj.company_name = company_name;

    if (!company_registration_date) {
      return res.status(400).send({
        status: false,
        message: "Company Registration date is required",
      });
    }
    obj.company_registration_date = company_registration_date;

    if (!company_bank) {
      return res
        .status(400)
        .send({ status: false, message: "Company bank is required" });
    }
    obj.company_bank = company_bank;

    if (!dt_company_activity) {
      return res
        .status(400)
        .send({ status: false, message: "Dt Company Activity is required" });
    }
    obj.dt_company_activity = dt_company_activity;

    if (!dt_company_facility) {
      return res
        .status(400)
        .send({ status: false, message: "Dt Company Facility is required" });
    }
    obj.dt_company_facility = dt_company_facility;

    if (!company_legal_status) {
      return res
        .status(400)
        .send({ status: false, message: "Company legal status is required" });
    }
    obj.company_legal_status = company_legal_status;

    if (!share_capital) {
      return res
        .status(400)
        .send({ status: false, message: "Share Capital is required" });
    }
    obj.share_capital = share_capital;

    const RegistryId_certs = uuid.v4();
    obj.registry_id = RegistryId_certs;

    const company = await companyModel.create(obj);
    const user = await userModel.findOne({ _id: userId });
    let registryData = {
      registryId: RegistryId_certs,
      username: user.username,
      companyId: company._id,
    };
    await registryId.create(registryData);

    return res
      .status(201)
      .send({ status: false, message: "New Company Onboarded", data: company });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ status: false, Error: error.message });
  }
};

const saveShareHolderInfo = async function (req, res) {
  try {
    const { companyId, userId } = req.params;
    const {
      shareHolder_name,
      role_in_company,
      emirates_id,
      share_holding,
      mail_address,
      contact_number,
      additional_details,
    } = req.body;
    const files = req.files;
    console.log(req.files);
    let obj = {};
    // return res.send("hi")
    if (files.length < 4) {
      return res
        .status(400)
        .send({ status: false, message: "Please upload required files" });
    }

    const user = await userModel.findOne({ _id: userId });
    obj.onboarded_by = userId;

    const company = await companyModel.findOne({ _id: companyId });
    if (!company) {
      return res
        .status(404)
        .send({ status: false, message: "Company not found" });
    }
    obj.company_id = companyId;

    if (!shareHolder_name) {
      return res
        .status(400)
        .send({ status: false, message: "Share Holder name is required" });
    }
    obj.shareHolder_name = shareHolder_name;

    if (!role_in_company) {
      return res
        .status(400)
        .send({ status: false, message: "Share Holder name is required" });
    }
    obj.role_in_company = role_in_company;

    if (!emirates_id) {
      return res
        .status(400)
        .send({ status: false, message: "Share Holder name is required" });
    }
    const emiratesIdExist = await shareHolderModel.findOne({
      emirates_id: emirates_id,
    });
    if (emiratesIdExist) {
      return res
        .status(409)
        .send({ status: false, message: "Emirates Id already exists" });
    }
    obj.emirates_id = emirates_id;

    if (!share_holding) {
      return res
        .status(400)
        .send({ status: false, message: "Share Holder name is required" });
    }
    obj.share_holding = share_holding;

    if (!mail_address) {
      return res
        .status(400)
        .send({ status: false, message: "Share Holder name is required" });
    }
    const mailAddressExist = await shareHolderModel.findOne({
      mail_address: mail_address.toLowerCase(),
    });
    if (mailAddressExist) {
      return res
        .status(409)
        .send({ status: false, message: "Email already exist" });
    }
    obj.mail_address = mail_address.toLowerCase();

    if (!contact_number) {
      return res
        .status(400)
        .send({ status: false, message: "Share Holder name is required" });
    }
    const contactExist = await shareHolderModel.findOne({
      contact_number: contact_number,
    });
    if (contactExist) {
      return res
        .status(409)
        .send({ status: false, message: "Contact number already exist" });
    }
    obj.contact_number = contact_number;

    if (!additional_details) {
      return res
        .status(400)
        .send({ status: false, message: "Share Holder name is required" });
    }
    obj.additional_details = additional_details;

    const resultArr = await ipfsUtilFun.addMultiDataToIPFS(files);
    let ipfsArr = [];
    resultArr.map((ele) => ipfsArr.push(ele.IpfsHash));
    const uniqueSet = new Set(ipfsArr);
    if (uniqueSet.size !== ipfsArr.length) {
      return res.status(400).send({
        status: false,
        message: "Duplicate Documents found, Please upload valid document",
      });
    }

    let verificationdata = [];
    resultArr.map((ele) => {
      obj[`${ele.fileName}`] = ele.IpfsHash;
      verificationdata.push({
        company_id: companyId,
        doc_name: ele.fileName,
        hash: ele.IpfsHash,
      });
    });

    const shareData = await shareHolderModel.create(obj);

    let blockcahinOBJ = {
      registryId: company.registry_id,
      CompanyName: company.company_name,
      FinancialYearOfTheComapny: "2023",
      ProposedBankOfTheCompany: company.company_bank,
      ActivitiesOfTheRegistryCompany: company.dt_company_activity,
      FacilityOfTheRegistryCompany: company.dt_company_facility,
      LegalStatusOfTheCompany: company.company_legal_status,
      ShareCapital: company.share_capital,
      NameOfTheShareHolder: shareData.shareHolder_name,
      SelectRoleOfTheCompany: shareData.role_in_company,
      EmiratesId: shareData.emirates_id,
      ShareHoldingPercentage: shareData.share_holding,
      OfficialMailAddress: shareData.mail_address,
      ContactNumber: shareData.contact_number,
      AdditionalDetails: shareData.additional_details,
    };
    console.log("400", blockcahinOBJ);
    //blockchain code
    // load the network configuration
    const ccpPath = path.resolve(__dirname, "../connection-registry.json");
    const ccp = JSON.parse(fs.readFileSync(ccpPath, "utf-8"));

    // Create a new file system based wallet for managing identities.
    const walletPath = path.join(process.cwd(), "/walletRegistry");
    const wallet = await Wallets.newFileSystemWallet(walletPath);
    console.log(`Wallet path: ${walletPath}`);

    // Check to see if we've already enrolled the user.
    const identity = await wallet.get(user.username);
    console.log("433", user.username);
    if (!identity) {
      console.log(
        `An identity for the user "${user.username}" does not exist in the wallet`
      );
      console.log("Run the registerUser.js application before retrying");
    }

    // Create a new gateway for connecting to our peer node.
    const gateway = new Gateway();
    await gateway.connect(ccp, {
      wallet,
      identity: user.username,
      discovery: {
        enabled: true,
        asLocalhost: true,
      },
    });

    // Get the network (channel) our contract is deployed to.
    const network = await gateway.getNetwork("registry-channel");

    // Get the contract from the network.
    const contract = network.getContract("registry");
    console.log("440");
    var bctransaction = await contract.createTransaction(
      "StoreOnboardingCompanyAndShareHolding"
    );
    console.log("469", bctransaction);
    let result = bctransaction
      .submit(
        company.registry_id,
        company.company_name,
        "2023",
        company.company_bank,
        company.dt_company_activity,
        company.dt_company_facility,
        company.company_legal_status,
        company.share_capital,
        shareData.shareHolder_name,
        shareData.role_in_company,
        shareData.emirates_id,
        shareData.share_holding,
        shareData.mail_address,
        shareData.contact_number,
        shareData.additional_details
      )
      .then((data) => console.log("477", data))
      .catch((err) => console.log(err));
    console.log("487", result);
    // console.log("468", result.toString('utf-8'))
    let txID = bctransaction.getTransactionId();
    console.log("482", txID);

    // Disconnect from the gateway.
    await gateway.disconnect();
    console.log("Transaction has been submitted");

    verificationdata.map((ele) => {
      ele["share_holder_id"] = shareData._id;
      ele["txID"] = txID;
    });
    await verificationModel.insertMany(verificationdata);

    await companyModel.findOneAndUpdate(
      { _id: companyId },
      { $set: { txID: txID } }
    );
    return res
      .status(200)
      .send({ Status: true, message: "Files uploaded", data: shareData });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ status: false, Error: error.message });
  }
};

const uploadCompanyDocuments = async function (req, res) {
  try {
    const { userId, companyId } = req.params;
    let obj = {};
    const files = req.files;
    const user = await userModel.findOne({ _id: userId });
    if (files.length < 9) {
      return res
        .status(400)
        .send({ status: false, message: "Upload required Files" });
    }

    const company = await companyModel.findOne({ _id: companyId });
    if (!company) {
      return res
        .status(404)
        .send({ status: false, message: "Company not found" });
    }
    obj.company_id = companyId;

    const resultArr = await ipfsUtilFun.addMultiDataToIPFS(files);
    let ipfsArr = [];
    resultArr.map((ele) => ipfsArr.push(ele.IpfsHash));
    const uniqueSet = new Set(ipfsArr);
    if (uniqueSet.size !== ipfsArr.length) {
      return res.status(400).send({
        status: false,
        message: "Duplicate Documents found, Please upload valid document",
      });
    }

    console.log("419", resultArr);

    let verificationdata = [];
    resultArr.map((ele) => {
      obj[`${ele.fileName}`] = ele.IpfsHash;
      verificationdata.push({
        company_id: companyId,
        doc_name: ele.fileName,
        hash: ele.IpfsHash,
      });
    });

    const RegistryId_certs = company.registry_id;
    const documents = await companyDocumentModel.create(obj);

    const shareHolderDocs = await shareHolderModel
      .findOne({ company_id: companyId })
      .lean();

    //blockchain code
    const ccpPath = path.resolve(__dirname, "../connection-registry.json");
    const ccp = JSON.parse(fs.readFileSync(ccpPath, "utf-8"));

    // Create a new file system based wallet for managing identities.
    const walletPath = path.join(process.cwd(), "/walletRegistry");
    const wallet = await Wallets.newFileSystemWallet(walletPath);
    console.log(`Wallet path: ${walletPath}`);
    const identity = await wallet.get(user.username);
    console.log(identity);
    if (!identity) {
      return res.status(400).send({
        status: false,
        message: `An identity for the user "${user.username}" does not exist in the wallet`,
      });
    }
    console.log("408", user.username);
    const gateway = new Gateway();
    await gateway.connect(ccp, {
      wallet,
      identity: user.username,
      discovery: {
        enabled: true,
        asLocalhost: true,
      },
    });
    // Create a new gateway for connecting to our peer node.
    // Get the network (channel) our contract is deployed to.
    const network = await gateway.getNetwork("registry-channel");
    console.log("544", network);
    // Get the contract from the network.
    const contract = await network.getContract("registry");
    console.log("547", contract);

    var bctransaction = await contract.createTransaction(
      "PutCertificatesUploaded"
    );
    let result = await bctransaction.submit(
      RegistryId_certs,
      documents["Incorporation"],
      documents["MoaAndAoa"],
      documents["Incumberency"],
      documents["UndertakingLetterOfShareCapital"],
      documents["AuthorizationLetter"],
      documents["DeclerationOfUltimateBenefitialOwners"],
      shareHolderDocs["ValidPassportCopy"],
      shareHolderDocs["UtilityBillForAddressProof"],
      shareHolderDocs["EmirateId"],
      shareHolderDocs["BussinessProfile"],
      documents["IncorporationOfSubsidaryInDmcc"]
    );
    let txID = bctransaction.getTransactionId();
    // Disconnect from the gateway.
    await gateway.disconnect();
    console.log("Transaction has been submitted");

    verificationdata.map((ele) => {
      ele["share_holder_id"] = shareHolderDocs._id;
      ele["txID"] = txID;
    });
    await verificationModel.insertMany(verificationdata);

    await companyDocumentModel.findOneAndUpdate(
      { company_id: companyId },
      { $set: { txID: txID } }
    );
    //../../registry-network/organizations/peerOrganizations/registry.blockchain.com/tlsca/tlsca.registry.blockchain.com-cert.pem
    return res.status(201).send({
      status: true,
      message: "Documents saved successfully",
      data: documents,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ status: false, Error: error.message });
  }
};

const forgotPassword = async function (req, res) {
  try {
    const { username } = req.body;

    const user = await adminModel.findOne({
      $or: [
        { username: username.toLowerCase() },
        { email: username.toLowerCase() },
      ],
    });
    if (!user) {
      return res
        .status(404)
        .send({ status: false, message: "Invalid Username!" });
    }

    const otp = randomString.generate({
      length: 6,
      charset: "numeric",
    });
    forgotPasswordMail(user, otp)
      .then(async (result) => {
        if (result) {
          console.log(result);
          const otpExpiry = Date.now() + 300000; //5 minutes
          await userModel.findOneAndUpdate(
            { email: user.email },
            { $set: { OTP: otp, OTPExpiry: otpExpiry, forgotPassword: true } }
          );
          return res.status(200).send({
            status: true,
            message: "OTP has been sent to your mail " + user.email,
          });
        }
      })
      .catch((error) => {
        console.log(error);
        return res.status(400).send({
          status: false,
          message:
            "Something went wrong! Please try again" + " " + error.message,
        });
      });
    // const coded_password = await bcrypt.hash(newPassword, 10);
    // const updatedUser = await userModel.findOneAndUpdate(
    //   { _id: user._id },
    //   { $set: { password: newPassword, coded_password: coded_password } },
    //   { new: true }
    // );

    // return res.status(200).send({
    //   status: true,
    //   message: "New Password updated successfully",
    //   data: updatedUser,
    // });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ status: false, Error: error.message });
  }
};

const forgotPasswordOTPVerification = async function (req, res) {
  try {
    let { otp, email } = req.body;
    if (!otp) {
      return res
        .status(400)
        .send({ status: false, message: "OTP is required" });
    }
    if (!email) {
      return res
        .status(400)
        .send({ status: false, message: "email is required" });
    }
    let admin = await adminModel.findOne({ email: email });
    if (!admin) {
      return res
        .status(404)
        .send({ status: false, message: "User Data not found" });
    }
    if (admin.OTPExpiry < Date.now()) {
      admin.OTP = null;
      (admin.OTPExpiry = null),
        admin.forgotPassword == true
          ? (admin.forgotPassword = false)
          : (admin.forgotPassword = null);
      await amdinModel.findOneAndUpdate({ _id: id }, { $set: admin });
      return res.status(400).send({ status: false, message: "Invalid OTP" });
    } else {
      if (otp == user.OTP) {
        user.OTP = null;
        user.OTPExpiry = null;
        if (user.forgotPassword == true) user.forgotPassword = false;
        let loggedInUser = await userModel.findOneAndUpdate(
          { email: email },
          { $set: user },
          { new: true }
        );
        return res.status(200).send({
          status: true,
          message: "OTP verification Successful",
          data: loggedInUser,
        });
      } else {
        user.OTP = null;
        (user.OTPExpiry = null),
          user.forgotPassword == true
            ? (user.forgotPassword = false)
            : (user.forgotPassword = null);
        await userModel.findOneAndUpdate({ _id: id }, { $set: user });
        return res.status(400).send({ status: false, message: "Invalid OTP" });
      }
    }
  } catch (error) {
    return res.status(500).send({ status: false, Error: error.message });
  }
};

const resetPassword = async function (req, res) {
  try {
    const { newPassword } = req.body;
    const { userId } = req.params;
    let user = await userModel.findOne({ _id: userId });
    if (!user) {
      return res.status(404).send({ status: false, message: "User not found" });
    }

    if (user.forgotPassword == false) {
      let pass = await bcrypt.hash(newPassword, 10);
      user.password = newPassword;
      user.coded_password = pass;
      user.forgotPassword = null;
      let updatedUser = await userModel.findOneAndUpdate(
        { _id: userId },
        { $set: user },
        { new: true }
      );
      //send reset mail
      await resetPasswordMail(updatedUser);
      return res.status(200).send({
        status: true,
        message: "Password updated successfully",
        data: updatedUser,
      });
    } else {
      return res
        .status(400)
        .send({ status: false, message: "verify your otp first" });
    }
  } catch (error) {
    return res.status(500).send({ status: false, Error: error.message });
  }
};

const getAllApprovedIssuers = async function (req, res) {   //complete
  try {
    const { userId } = req.params;
    const issuers = await issuerModel
      .find({ approved: true })
      .sort({ createdAt: -1 });

    if (issuers.length == 0) {
      return res
        .status(404)
        .send({ status: false, message: "No Issuer found" });
    }

    return res.status(200).send({
      status: true,
      message: "Issuer details fetched successfully",
      data: issuers,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ status: false, Error: error.message });
  }
};


const getAllUnapprovedIssuers = async function (req, res) {   //complete
  try {
    const { userId } = req.params;
    const issuers = await issuerModel
      .find({ approved: false })
      .sort({ createdAt: -1 });

    if (issuers.length == 0) {
      return res
        .status(404)
        .send({ status: false, message: "No Issuer found" });
    }

    return res.status(200).send({
      status: true,
      message: "Issuer details fetched successfully",
      data: issuers,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ status: false, Error: error.message });
  }
};

const approveIssuer = async function (req,res){                                                 //complete
  try{
    const {issuer_user_name} = req.params;
    const issuer = await issuerModel.findOne({issuer_user_name : issuer_user_name})

    if (!issuer) {
      return res.status(404).send({ status: false, message: "Issuer not found" });
    }

    if (issuer.approved == false){
      await issuerModel.findOneAndUpdate(
        {_id: issuer.id},
        {$set: {approved : true}}
      )
    }

  }catch(error){
    console.log(error)
    return res.status(500).send({ status: false, Error: error.message });
  }
}


const blockIssuer = async function (req,res){                                                 //complete
  try{
    const {issuer_user_name} = req.params;
    const issuer = await issuerModel.findOne({issuer_user_name : issuer_user_name})

    if (!issuer) {
      return res.status(404).send({ status: false, message: "Issuer not found" });
    }

    if (issuer.approved == true){
      await issuerModel.findOneAndUpdate(
        {_id: issuer.id},
        {$set: {blocked : true}}
      )
    } else{
      return res.status(404).send({status: false, message: "Issuer not approved"})
    }

  }catch(error){
    console.log(error)
    return res.status(500).send({ status: false, Error: error.message });
  }
}


const unblockIssuer = async function (req,res){                                                 //complete
  try{
    const {issuer_user_name} = req.params;
    const issuer = await issuerModel.findOne({issuer_user_name : issuer_user_name})

    if (!issuer) {
      return res.status(404).send({ status: false, message: "Issuer not found" });
    }

    if (issuer.approved == true && issuer.blocked == true){
      await issuerModel.findOneAndUpdate(
        {_id: issuer.id},
        {$set: {blocked : false}}
      )
    } else{
      return res.status(404).send({status: false, message: "Issuer not approved"})
    }

  }catch(error){
    console.log(error)
    return res.status(500).send({ status: false, Error: error.message });
  }
}



const getAllApprovedAgents = async function (req, res) {   //complete
  try {
    const { userId } = req.params;
    const agents = await agentModel
      .find({ approved: true })
      .sort({ createdAt: -1 });

    if (agents.length == 0) {
      return res
        .status(404)
        .send({ status: false, message: "No Ahent found" });
    }

    return res.status(200).send({
      status: true,
      message: "Agent details fetched successfully",
      data: agentss,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ status: false, Error: error.message });
  }
};


const getAllUnapprovedAgents = async function (req, res) {   //complete
  try {
    const { userId } = req.params;
    const agents = await agentModel
      .find({ approved: false })
      .sort({ createdAt: -1 });

    if (agentss.length == 0) {
      return res
        .status(404)
        .send({ status: false, message: "No company found" });
    }

    return res.status(200).send({
      status: true,
      message: "Company details fetched successfully",
      data: agents,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ status: false, Error: error.message });
  }
};

const approveAgent = async function (req,res){                                                 //complete
  try{
    const {agent_user_name} = req.params;
    const agent = await issuerModel.findOne({agent_user_name : issuer_user_name})

    if (!agent) {
      return res.status(404).send({ status: false, message: "Agent not found" });
    }

    if (issuer.approved == false){
      await issuerModel.findOneAndUpdate(
        {_id: issuer.id},
        {$set: {approved : true}}
      )
    }

  }catch(error){
    console.log(error)
    return res.status(500).send({ status: false, Error: error.message });
  }
}


const blockAgent = async function (req,res){                                                 //complete
  try{
    const {_user_name} = req.params;
    const agent = await agentModel.findOne({agent_user_name : agent_user_name})

    if (!agent) {
      return res.status(404).send({ status: false, message: "Agent not found" });
    }

    if (agent.approved == true){
      await agentModel.findOneAndUpdate(
        {_id: agent.id},
        {$set: {blocked : true}}
      )
    } else{
      return res.status(404).send({status: false, message: "Agent not approved"})
    }

  }catch(error){
    console.log(error)
    return res.status(500).send({ status: false, Error: error.message });
  }
}


const unblockAgent = async function (req,res){                                                 //complete
  try{
    const {agent_user_name} = req.params;
    const agent = await agentModel.findOne({agent_user_name : agent_user_name})

    if (!agent) {
      return res.status(404).send({ status: false, message: "Agent not found" });
    }

    if (agent.approved == true && agent.blocked == true){
      await agentModel.findOneAndUpdate(
        {_id: agent.id},
        {$set: {blocked : false}}
      )
    } else{
      return res.status(404).send({status: false, message: "Agent not approved"})
    }

  }catch(error){
    console.log(error)
    return res.status(500).send({ status: false, Error: error.message });
  }
}


const getDashboardData = async function (req, res) {
  try {
    const { userId } = req.params;

    let pipeline = [
      {
        $match: {
          onboarded_by: new mongoose.Types.ObjectId(userId),
        },
      },
      {
        $group: {
          _id: null,
          totalCompanies: { $sum: 1 },
          totalverifiedCompanies: {
            $sum: { $cond: [{ $eq: ["$isVerified", true] }, 1, 0] },
          },
          totalunverifiedCompanies: {
            $sum: { $cond: [{ $eq: ["$isVerified", false] }, 1, 0] },
          },
          totalmismatchedCompanies: {
            $sum: { $cond: [{ $eq: ["$isMismatched", true] }, 1, 0] },
          },
        },
      },
    ];

    const dashboardData = await companyModel.aggregate(pipeline);

    return res.status(200).send({
      status: true,
      message: "Dashboard data fetched successfully",
      data: dashboardData,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ status: false, Error: error.message });
  }
};

const getAllDocsOfCompany = async function (req, res) {
  try {
    const { userId, companyId } = req.params;
    const user = await userModel.findOne({ _id: userId });
    const company = await companyModel.findOne({ _id: companyId });
    if (!company) {
      return res
        .status(404)
        .send({ status: false, message: "Company not found" });
    }
    const companyDOcs = await verificationModel.find({ company_id: companyId });
    if (companyDOcs.length == 0) {
      return res
        .status(400)
        .send({ status: false, message: "No Document found for this company" });
    }

    //blockchain Code
    // load the network configuration
    const ccpPath = path.resolve(__dirname, "../connection-registry.json");
    const ccp = JSON.parse(fs.readFileSync(ccpPath, "utf-8"));

    // Create a new file system based wallet for managing identities.
    const walletPath = path.join(process.cwd(), "/walletRegistry");
    const wallet = await Wallets.newFileSystemWallet(walletPath);
    console.log(`Wallet path: ${walletPath}`);
    console.log("353", user.username);
    // Check to see if we've already enrolled the user.
    const identity = await wallet.get(user.username);
    if (!identity) {
      console.log(
        `An identity for the user "${user.username}" does not exist in the wallet`
      );
      console.log("Run the registerUser.js application before retrying");
      throw new Error(
        `An identity for the user ${user.username.toUpperCase()} does not exist in the wallet`
      );
      return;
    }

    // Create a new gateway for connecting to our peer node.
    const gateway = new Gateway();
    await gateway.connect(ccp, {
      wallet,
      identity: user.username,
      discovery: {
        enabled: true,
        asLocalhost: true,
      },
    });

    // Get the network (channel) our contract is deployed to.
    const network = await gateway.getNetwork("registry-channel");

    // Get the contract from the network.
    const contract = network.getContract("registry");

    // Evaluate the specified transaction
    // QueryGeneratedRubberCert has 1 argument : rubberBatchNumber string
    // ex: {'QueryGeneratedRubberCert', 'rubber1'}
    console.log(gateway);
    const result = await contract.evaluateTransaction(
      "GetCertificatesUploaded",
      company.registry_id
    );
    let resultParsed = JSON.parse(result.toString());
    return res.status(200).send({
      status: true,
      message: "Company docs fetched successfully",
      data: companyDOcs,
      result: resultParsed,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ status: false, Error: error.message });
  }
};


const verifyCompanyDocuments = async function (req, res) {
  try {
    const { userId, companyId } = req.params;
    const { doc_name } = req.body;
    const user = await userModel.findOne({ _id: userId });
    const company = await companyModel
      .findOne({ _id: companyId, isVerified: false })
      .lean();
    if (!company) {
      return res.status(400).send({
        status: false,
        message: "This Company's all document have been verified",
      });
    }
    const docData = await verificationModel.findOne({
      company_id: companyId,
      doc_name: doc_name,
    });
    if (!docData) {
      await verificationModel.findOneAndUpdate(
        { company_id: companyId, doc_name: doc_name },
        { $set: { isMismatched: true } },
        { new: true }
      );
      return res
        .status(404)
        .send({ status: false, message: "VERIFICATION FAILED AND DOCUMENT MISMATCHED" });
    }

    //-----------------------------------------send the IPFS hash to blockchain-----------------------------------------//
    // load the network configuration
    if (
      ![
        "NOC",
        "ManagementConsultancy",
        "BusinessPlan",
        "SpecimenSignature",
        "ShareHolderResolution",
        "BankStatement",
        "DeclarationFromLebanese",
      ].includes(doc_name)
    ) {
      console.log("inside blockchain flow")
      const ccpPath = path.resolve(__dirname, "../connection-registry.json");
      const ccp = JSON.parse(fs.readFileSync(ccpPath, "utf-8"));

      // Create a new file system based wallet for managing identities.
      const walletPath = path.join(process.cwd(), "/walletRegistry");
      const wallet = await Wallets.newFileSystemWallet(walletPath);
      console.log(`Wallet path: ${walletPath}`);
      console.log("353", user.username);
      // Check to see if we've already enrolled the user.
      const identity = await wallet.get(user.username);
      if (!identity) {
        console.log(
          `An identity for the user ${user.username} does not exist in the wallet`
        );
        console.log("Run the registerUser.js application before retrying");
        throw new Error(
          `An identity for the user ${user.username.toUpperCase()} does not exist in the wallet`
        );
        return;
      }

      // Create a new gateway for connecting to our peer node.
      const gateway = new Gateway();
      await gateway.connect(ccp, {
        wallet,
        identity: user.username,
        discovery: {
          enabled: true,
          asLocalhost: true,
        },
      });

      // Get the network (channel) our contract is deployed to.
      const network = await gateway.getNetwork("registry-channel");

      // Get the contract from the network.
      const contract = network.getContract("registry");

      // Evaluate the specified transaction

      var bctransaction = await contract.createTransaction("VerifyDocument");
      console.log("1043", company.registry_id, docData.hash);
      let result = await bctransaction.submit(
        company.registry_id,
        docData.hash
      );
      if (result.toString() == "") {
        console.log("VERIFICATION FAILED");
        await verificationModel.findOneAndUpdate(
          { company_id: companyId, doc_name: doc_name },
          { $set: { isMismatched: true } },
          { new: true }
        );
        return res.status(400).send({
          status: false,
          message: "VERIFICATION FAILED FROM BLOCKCHAIN",
        });
      }
      console.log("1041", result.toString());
      let resultParsed = JSON.parse(result.toString());
      console.log("VERIFICATION SUCCESSFULL", resultParsed);

      console.log("1041", result.toString());
      let resultParsed2 = JSON.parse(result.toString());
      console.log("MATCHING SUCCESSFULL", resultParsed2);
    }

    //after successfull verification turn the isVerified key to true
    const verifyDoc = await verificationModel.findOneAndUpdate(
      { company_id: companyId, doc_name: doc_name },
      { $set: { isVerified: true } },
      { new: true }
    );

    const totalDOc = await verificationModel.find({ company_id: companyId });
    company.verified_doc_Count = company.verified_doc_Count + 1;
    if (totalDOc.length === company.verified_doc_Count) {
      company.isVerified = true;
      const password = generatePassword();
      const coded_password = await bcrypt.hash(password, 10);
      const updatedCompany = await companyModel.findOneAndUpdate(
        { _id: company._id },
        { $set: company }
      );
      const shareHolderData = await shareHolderModel.findOneAndUpdate(
        { company_id: companyId },
        { $set: { password: password, coded_password: coded_password } },
        { new: true }
      );

      welcomMail(shareHolderData)
        .then(async (result) => {
          console.log("847");
          return res.status(200).send({
            status: false,
            message:
              "All Document verified successfully and credentials sent to respective user",
            data: updatedCompany,
          });
        })
        .catch((error) => {
          console.log(error);
          return res.status(400).send({
            status: false,
            message:
              "Something went wrong while sending the mail!" +
              " " +
              error.message,
          });
        });
    } else {
      await companyModel.findOneAndUpdate(
        { _id: company._id },
        { $set: company }
      );

      return res.status(200).send({
        status: false,
        message: "Document verified successfully",
        data: verifyDoc,
      });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ status: false, Error: error.message });
  }
};

const getParticularDocDetails = async function (req, res) {
  try {
    const { companyId, hash } = req.params;
    const company = await companyModel.findOne({ _id: companyId });
    if (!company) {
      return res
        .status(404)
        .send({ status: false, message: "Company not found" });
    }

    const docDetail = await verificationModel.findOne({
      company_id: companyId,
      hash: hash,
    });
    if (!docDetail) {
      return res
        .status(404)
        .send({ status: false, message: "Document Drtail not founc" });
    }

    return res.status(200).send({
      status: true,
      message: "Document details fetched successfully",
      data: docDetail,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ status: false, Error: error.message });
  }
};


module.exports = {
  login,
  onboardCompany,
  generateToken,
  saveShareHolderInfo,
  uploadCompanyDocuments,
  forgotPassword,
  forgotPasswordOTPVerification,
  resetPassword,
  getDashboardData,
  getAllDocsOfCompany,
  verifyCompanyDocuments,
  getParticularDocDetails,
  getAllApprovedIssuers,
  getAllUnapprovedIssuers,
  approveIssuer,
  blockIssuer,
  unblockIssuer,
  getAllApprovedAgents,
  getAllUnapprovedAgents,
  approveAgent,
  blockAgent,
  unblockAgent
};
