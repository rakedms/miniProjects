let database= {
    db_url: "mongodb://localhost:27017/registry"
}

let JWT = {
    access_key: "@dmcc&^%83*)--420!&&*",
    access_expiry: "1h",
    refresh_key: "@dmcc&0-=)/>.%#765@56",
    refresh_expiry: "1d",
}

let PINATA_CONFIG ={
    api_key:"4ebc3620860178b0d752",
    api_secret: "390d6c6bfe4f3ebe876f3bff6aeb96a7179e57f6e4f8d4e045ff912ac5e9ee3f"
}

let email_config = {
    host: "smtp.office365.com",
    port: 587,
    user: "noreply@simplyfi.tech",
    pass: "S!mply5tec#",
    from: "Blockchain-Registry <noreply@simplyfi.tech>"
}

module.exports= {database, JWT, PINATA_CONFIG, email_config};