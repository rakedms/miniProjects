const { registerEnroll } = require("./registerEnrollClientUserRegistry");
let express = require("express");
let bodyParser = require("body-parser");
const qr = require("qrcode");
const multer = require("multer");
let app = express();
const {login,
    onboardCompany,
    generateToken,
    forgotPassword,
    forgotPasswordOTPVerification,
    resetPassword,
    approveIssuer,
    blockIssuer,
    unblockIssuer,
    getAllApprovedAgents,
    getAllUnapprovedAgents,
    approveAgent,
    blockAgent,
    unblockAgent,
    getAllUnapprovedIssuers,
    getAllApprovedIssuers} = require ("./contoller/adminController")



app.get("/", async function (req, res) {
    try {
      console.log("Test Pass!..");
      res.status(200).send({ response: "Test Pass!..." });
      console.log("33");
    } catch (error) {
      console.log("Test Fail!..");
      // process.exit(1)
    }
  });
  console.log("39");


app.get("/refresh", refreshauth, generateToken);
app.post("/api/signUp", signUp);
app.post("/api/login", login);


app.get("/api/getAllApprovedIssuers", 
   response = getAllApprovedIssuers
)

app.get("/api/getAllUnapprovedIssuers", 
    getAllUnapprovedIssuers
)

app.get("/api/getAllApprovedAgents",
    getAllApprovedAgents
)

app.get("/api/getAllUnapprovedAgents",
    getAllUnapprovedAgents
)

