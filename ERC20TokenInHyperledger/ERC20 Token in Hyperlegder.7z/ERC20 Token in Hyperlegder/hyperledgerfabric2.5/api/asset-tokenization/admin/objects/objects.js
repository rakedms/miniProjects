//Asset types

let equityAsset = {
    "asset-name": "CNA",
    "asset-class": "Equity",
    "asset-type": "ETF",
    "symbol": "XYZ",
    "exchange": "NASDAQ",
    "price": "111",
    "volume": "1000",
    "dividend": "8",
    "yield": "8",
    "ratio": "1",
    "sector": "Technology",
    "document": "11234543454"    
}

let tradeFinanceAsset = {
    "asset-name": "LC-1235",
    "asset-class": "Trand Finance",
    "asset-type": "LC",
    "symbol": "XYZ",
    "issuer": "Originator Name",
    "beneficiary": "Supplier/Expoter",
    "amount": "in INR",
    "currency": "USD",
    "maturity": "45",
    "interest": "% per annum",
    "collateral": "invoices",
    "status": "Active",
    "document" : "11234543454"      
}


let commoditiesAsset = {
    "asset-name": "LC-1235",
    "asset-class": "Commodities",
    "asset-type": "Precious Metal/Fuel/Grain",
    "symbol": "upload",
    "unit": "0" ,
    "price": "USD/BBL",
    "souce": "origin",
    "quality": "Grade/Purity/Density/Moisture",
    "location": "Destination of commodity",
    "delivery": "settlement date of commodity",
    "contract": "duration/price",
    "document" : "11234543454"  
}


module.exports = {
    equityAsset,
    tradeFinanceAsset,
    commoditiesAsset
}
