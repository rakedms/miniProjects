const mongoose = require('mongoose')

const investorSchema = new mongoose.Schema({
    username:{
        type:String,
        required:true,
        unique:true
    },
    email:{
        type:String,
        required:true,
        unique:true
    },
    mob_no:{
        type:String,
        required:true
    },
    creationDate:{
        type:Date,
        required:true
    },
    coded_password:{
        type:String,
        required:true
    },
    password_update_date:{
        type:Date,
        required:true
    },
    OTP:{
        type:String,
        default:null
    },
    OTPExpiry:{
        type:Date,
        default:null
    },
    forgotPassword:{
        type:Boolean,
        default:false
    },
    status:{
        type:Boolean,
        required:true
    }
    
},{timestamps:true})

module.exports = mongoose.model('investor', investorSchema)