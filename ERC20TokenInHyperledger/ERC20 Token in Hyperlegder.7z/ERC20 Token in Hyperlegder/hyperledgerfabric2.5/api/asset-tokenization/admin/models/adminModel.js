const mongoose = require('mongoose')

const adminSchema = new mongoose.Schema({
    issuer_user_name:{
        type:String,
        required:true,
        unique:true
    },
    email:{
        type:String,
        required:true,
        unique:true
    },
    mob_no:{
        type:String,
        required:true
    },
    creationDate:{
        type:Date,
        required:true
    },
    password:{
        type:String,
        required:true
    },
    coded_password:{
        type:String,
        required:true
    },
    password_update_date:{
        type:Date,
        required:true
    },
    OTP:{
        type:String,
        default:null
    },
    OTPExpiry:{
        type:Date,
        default:null
    },
    forgotPassword:{
        type:Boolean,
        default:false
    },
    status:{
        type:Boolean,
        required:true
    }
},{timestamps:true})

module.exports = mongoose.model('admin', adminSchema)