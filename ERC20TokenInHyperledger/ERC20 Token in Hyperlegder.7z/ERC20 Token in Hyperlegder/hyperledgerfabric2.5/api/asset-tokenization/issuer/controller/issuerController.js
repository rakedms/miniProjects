const bcrypt = require("bcrypt");
const issuerModel = require("../models/issuerModel");
const { registerEnroll } = require("../registerEnrollIssuer");
const { JWT } = require("../configs/config");
const jwt = require("jsonwebtoken");
const Joi = require('joi');
const { Gateway, Wallets } = require("fabric-network");
const path = require("path");
const fs = require("fs");
const mongoose = require("mongoose");
const uuid = require("uuid");
const registryId = require("../models/registryId.js");
const axios = require("axios");
const randomString = require("randomstring");


const {
    forgotPasswordMail,
    resetPasswordMail,
    welcomMail,
  } = require("../utils/mailService.js");

const { generatePassword } = require("../utils/utils.js");
const { Console } = require("console");


const signUp = async function (req, res) {
  try {
    const { username, email, mob_no, ownership, address, number_of_units, company_name, password } = req.body;

    const usernameSchema = Joi.string().alphanum().min(3).max(30).required();
    const usernameValidationResult = usernameSchema.validate(username);
    if (usernameValidationResult.error) {
      return res.status(400).json({ error: usernameValidationResult.error.details[0].message });
    }

    const emailSchema = Joi.string().email().required();
    const emailValidationResult = emailSchema.validate(email);
    if (emailValidationResult.error) {
      return res.status(400).json({ error: emailValidationResult.error.details[0].message });
    }    

    const mobileNumberSchema = Joi.string().regex(/^[0-9]{10}$/).required();
    const mobileNumberValidationResult = mobileNumberSchema.validate(mob_no);
    if (mobileNumberValidationResult.error) {
      return res.status(400).json({ error: mobileNumberValidationResult.error.details[0].message });
    }

    const ownershipSchema = Joi.string().required();
    const ownershipValidationResult = ownershipSchema.validate(ownership);
    if (ownershipValidationResult.error) {
      return res.status(400).json({ error: ownershipValidationResult.error.details[0].message });
    }

    const addressSchema = Joi.string().required();
    const addressValidationResult = addressSchema.validate(address);
    if (addressValidationResult.error) {
      return res.status(400).json({ error: addressValidationResult.error.details[0].message });
    }

    const numberOfUnitsSchema = Joi.number().integer().min(1).required();
    const numberOfUnitsValidationResult = numberOfUnitsSchema.validate(number_of_units);
    if (numberOfUnitsValidationResult.error) {
      return res.status(400).json({ error: numberOfUnitsValidationResult.error.details[0].message });
    }

    const companyNameSchema = Joi.string().required();
    const companyNameValidationResult = companyNameSchema.validate(company_name);
    if (companyNameValidationResult.error) {
      return res.status(400).json({ error: companyNameValidationResult.error.details[0].message });
    }


    const passwordSchema = Joi.string().pattern(new RegExp('^[a-zA-Z0-9]{3,30}$')).required();
    const passwordValidationResult = passwordSchema.validate(password);
    if (passwordValidationResult.error) {
      return res.status(400).json({ error: passwordValidationResult.error.details[0].message });
    }      


    let obj = {};
    // if (!username) {
    //   return res
    //     .status(400)
    //     .send({ status: false, message: "User name is required" });
    // }
    const usernameExists = await userModel.findOne({
      username: username.toLowerCase(),
    });
    if (usernameExists) {
      return res.status(409).send({
        Status: false,
        message: `Username - ${username} already exists`,
      });
    }
    obj.username = username.toLowerCase();

    // if (!email) {
    //   return res
    //     .status(400)
    //     .send({ status: false, message: "Email is required" });
    // }
    const emailExists = await userModel.findOne({ email: email.toLowerCase() });
    if (emailExists) {
      return res
        .status(409)
        .send({ Status: false, message: `Email - ${email} already exists` });
    }
    obj.email = email.toLowerCase();

    // if (!password) {
    //   return res
    //     .status(400)
    //     .send({ status: false, message: "Password is required" });
    // }
    obj.mob_no = mob_no;
    obj.ownership = ownership;
    obj.address = address;
    obj.number_of_units = number_of_units;
    obj.company_name = company_name;
    obj.password = password;
    obj.coded_password = await bcrypt.hash(password, 10);
    obj.password_update_date = new Date();


    let err = await registerEnroll(username.toLowerCase());
    if (err) {
      throw new Error(err);
    }
    console.log(
      `Successfully registered and enrolled user ${username} and imported it into the wallet`
    );

    const issuer = await issuerModel.create(obj);
    return res.status(201).send({
      status: true,
      message: "Issuer Created Successfully and imported into the Wallet",
      data: issuer,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ status: false, Error: error.message });
  }
};
  

const login = async function (req, res) {
  try {
    const { username, password } = req.body;

    if (!username) {
      return res
        .status(400)
        .send({ status: false, message: "Username is required" });
    }
    if (!password) {
      return res
        .status(400)
        .send({ status: false, message: "Password is required" });
    }

    const issuer = await issuerModel.findOne({
      $or: [
        { username: username.toLowerCase() },
        { email: username.toLowerCase() },
      ],
    });
    if (!issuer) {
      return res
        .status(404)
        .send({ status: false, message: "Invalid Username!" });
    }
    let match = await bcrypt.compare(password, issuer.coded_password);
    if (!match) {
      return res
        .status(400)
        .send({ status: false, message: "Password is Incorrect" });
    }

    let access_token = jwt.sign(
      {
        issuer_id: issuer._id,
        email: issuer.email,
        username: issuer.username,
      },
      JWT.access_key,
      { expiresIn: JWT.access_expiry }
    );

    let refresh_token = jwt.sign(
      {
        user_id: issuer._id,
        email: issuer.email,
        username: issuer.username,
      },
      JWT.refresh_key,
      { expiresIn: JWT.refresh_expiry }
    );

    return res.status(200).send({
      Status: true,
      message: "User Login successfull",
      data: user,
      access_token: access_token,
      refresh_token: refresh_token,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ status: false, Error: error.message });
  }
};


const generateToken = async (req, res) => {
  try {
    const { issuer_id } = req.token;
    let access_token;
    let issuer = await issuerModel.findOne({ _id: issuer_id });
    if (!issuer) {
      return res.status(404).send({status:false, message:"issuer not found"})
    }

    access_token = jwt.sign(
      {
        issuer_id: issuer._id,
        email: issuer.email,
        username: issuer.username,
      },
      JWT.access_key,
      { expiresIn: JWT.access_expiry }
    );

    return res.status(200).send({
      status: true,
      message: "Token Generated Successfully",
      data: { access_token: access_token },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ status: false, message: error.message });
  }
};



module.exports = {
  signUp,
  login,
  generateToken
}

