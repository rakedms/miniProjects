let express = require("express");
let bodyParser = require("body-parser");
// const qr = require("qrcode");
// const multer = require("multer");
let app = express();
const registerEnroll = require("./registerEnrollIssuer")

const { Gateway, Wallets } = require("fabric-network");
const path = require("path");
const fs = require("fs");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get("/api/issuer/", async function (req, res){
  try{console.log("Issuer server is running");
  res.status(200).send({
    response: "Issuer server"
  })
  }catch(error){
    console.log("Fail");
  }
})

app.post("/api/issuer/issuerSignup",
)

app.post("/api/issuer/issuerLogin",
)

app.get("api/issuer/refresh",
)

app.post("/api/issuer/registerenrollissuer/", async function (req, res) {
  console.log("33");
  try {
    console.log(req.body.username);
    let err = await registerEnroll(req.body.username);

    if (err) {
      throw new Error(err);
    }

    res.status(201).json({
      status: "pass",
      message: `Successfully registered and enrolled user ${req.body.username} and imported it into the wallet`,
    });
  } catch (error) {
    res.status(501).json({
      status: "fail",
      message: error.message,
    });
  }
});

app.post("api/issuer/addIssuer/:issuerId", async function (req,res) {
  try{
    const {issuerId} = req.params;
    const issuer = await issuerModel.findOne(issuerId);

    let reqData = JSON.parse(req.body.data);

    if (!issuer){
        res.status(404).send({status: false, message :"Issuer not found"})
    }

    const ccpPath = path.resolve(__dirname, "connection-issuer.json")
    const ccp = JSON.parse(fs.readFileSync(ccpPath, "utf-8"))

    const walletPath = path.join(process.cwd, "walletIssuer");
    const wallet = await (Wallets.newFileSystemWallet(walletPath));
    console.log(walletPath);

    try{
        const identity = wallet.get(issuer.issuerId)
        if (!identity){
            console.log("issuer not found");
            res.status(404).send({status: false, message : "Wallet Not Found"});

        }
    }catch(error){
        console.log("failed", error)
    }

    try {
        const gateway = new Gateway();
        await gateway.connect(ccp, {
          wallet,
          identity: issuerId,
          discovery: {
            enabled: true,
            asLocalhost: true,
          },
        });

        const network = await gateway.getNetwork("asset-channel");
        const contract = network.getContract("assetcode");

        await contract.submitTransaction("addIssuer",
               // parameters need to be passed
               // parameters need to be passed
               // parameters need to be passed
               // parameters need to be passed
               // parameters need to be passed
        )
        await gateway.disconnect();
        console.log("Transaction has been submitted");
        return res.status(201).send({
          result: "Transaction has been submitted",
        });
            }
    catch(error){
    console.log("Failed at" (error))

    }

}catch(error){
    
}

})

app.post("/api/issuer/issuerLogin/:issuerId",
)

app.post("/api/issuer/issuerSignup/:issuerId",
)

app.post("/api/issuer/forgotPassword/:issuerId",
)



app.post("/api/issuer/onboardAsset/:issuerId", async function (req, res) {
    try{
        const {issuerId} = req.params;
        const issuer = await issuerModel.findOne(issuerId);

        let reqData = JSON.parse(req.body.data);

        if (!issuer){
            res.status(404).send({status: false, message :"Issuer not found"})
        }

        const ccpPath = path.resolve(__dirname, "connection-issuer.json")
        const ccp = JSON.parse(fs.readFileSync(ccpPath, "utf-8"))

        const walletPath = path.join(process.cwd, "walletIssuer");
        const wallet = await (Wallets.newFileSystemWallet(walletPath));
        console.log(walletPath);

        try{
            const identity = wallet.get(issuer.issuerId)
            if (!identity){
                console.log("issuer not found");
                res.status(404).send({status: false, message : "Wallet Not Found"});

            }
        }catch(error){
            console.log("failed", error)
        }

        try {
            const gateway = new Gateway();
            await gateway.connect(ccp, {
              wallet,
              identity: issuerId,
              discovery: {
                enabled: true,
                asLocalhost: true,
              },
            });

            const network = await gateway.getNetwork("asset-channel");
            const contract = network.getContract("assetcode");

            await contract.submitTransaction("onboardAsset",
                    reqData.name,
                    reqData.typre,
                    reqData.Symbol,
                    reqData.Exchange,
                    reqData.Price,
                    reqData.Volume,
                    reqData.Dividend,
                    reqData.Yield,
                    reqData.Ratio,
                    reqData.Sector
                )
            await gateway.disconnect();
            console.log("Transaction has been submitted");
            return res.status(201).send({
              result: "Transaction has been submitted",
            });
                }
        catch(error){
        console.log("Failed at" (error))

        }

    }catch(error){
        
    }

})

app.post("/api/issuer/freezeAssets/:issuerId", async function (req, res) {
    try{
        const {issuerId} = req.params;
        const issuer = await issuerModel.findOne(issuerId);

        let reqData = JSON.parse(req.body.data);

        if (!issuer){
            res.status(404).send({status: false, message :"Issuer not found"})
        }

        const ccpPath = path.resolve(__dirname, "connection-issuer.json")
        const ccp = JSON.parse(fs.readFileSync(ccpPath, "utf-8"))

        const walletPath = path.join(process.cwd, "walletIssuer");
        const wallet = await (Wallets.newFileSystemWallet(walletPath));
        console.log(walletPath);

        try{
            const identity = wallet.get(issuer.issuerId)
            if (!identity){
                console.log("issuer not found");
                res.status(404).send({status: false, message : "Wallet Not Found"});

            }
        }catch(error){
            console.log("failed", error)
        }

        try {
            const gateway = new Gateway();
            await gateway.connect(ccp, {
              wallet,
              identity: issuerId,
              discovery: {
                enabled: true,
                asLocalhost: true,
              },
            });

            const network = await gateway.getNetwork("asset-channel");
            const contract = network.getContract("assetcode");

            await contract.submitTransaction("freezeAssets",
                    // parameters need to be passed
                    // parameters need to be passed
                    // parameters need to be passed
                    // parameters need to be passed
                    // parameters need to be passed
            )

            await gateway.disconnect();
            console.log("Transaction has been submitted");
            return res.status(201).send({
              result: "Transaction has been submitted",
            });
                }
        catch(error){
        console.log("Failed at" (error))

        }

    }catch(error){
        
    }

})


app.post("/api/issuer/sendForApproval/:issuerId", async function (req, res) {
    try{
        const {issuerId} = req.params;
        const issuer = await issuerModel.findOne(issuerId);

        let reqData = JSON.parse(req.body.data);

        if (!issuer){
            res.status(404).send({status: false, message :"Issuer not found"})
        }

        const ccpPath = path.resolve(__dirname, "connection-issuer.json")
        const ccp = JSON.parse(fs.readFileSync(ccpPath, "utf-8"))

        const walletPath = path.join(process.cwd, "walletIssuer");
        const wallet = await (Wallets.newFileSystemWallet(walletPath));
        console.log(walletPath);

        try{
            const identity = wallet.get(issuer.issuerId)
            if (!identity){
                console.log("issuer not found");
                res.status(404).send({status: false, message : "Wallet Not Found"});

            }
        }catch(error){
            console.log("failed", error)
        }

        try {
            const gateway = new Gateway();
            await gateway.connect(ccp, {
              wallet,
              identity: issuerId,
              discovery: {
                enabled: true,
                asLocalhost: true,
              },
            });

            const network = await gateway.getNetwork("asset-channel");
            const contract = network.getContract("assetcode");

            await contract.submitTransaction("sendForApproval",
                    // parameters need to be passed
                    // parameters need to be passed
                    // parameters need to be passed
                    // parameters need to be passed
                    // parameters need to be passed
            )
            
            await gateway.disconnect();
            console.log("Transaction has been submitted");
            return res.status(201).send({
              result: "Transaction has been submitted",
            });
                }
        catch(error){
        console.log("Failed at" (error))

        }

    }catch(error){
        
    }

})

app.post("/api/issuer/createPool/:issuerId",
)


app.listen(8084, () => {
  console.log("Issuer running on http://localhost:8084");
});







