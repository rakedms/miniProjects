export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_LOCALMSPID="IssuerMSP"
export CORE_PEER_TLS_ROOTCERT_FILE=${PWD}/../../issuer-network/organizations/peerOrganizations/issuer.asset.com/peers/peer0.issuer.asset.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=${PWD}/../../issuer-network/organizations/peerOrganizations/issuer.asset.com/users/Admin@issuer.asset.com/msp/
export CORE_PEER_ADDRESS=localhost:7051

export FABRIC_CFG_PATH=${PWD}/../../config/
#peer channel fetch newest issuer-channel.block -c issuer-channel --orderer orderer.dmcc.com:7050
peer channel getinfo -c issuer-channel > block.json 
cat block.json | cut -c 18- > assetInfo.json