package main

import (
	"encoding/json"
	"fmt"
	"log"
	"time"
	"os"
	"strconv"

	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/golang/protobuf/ptypes"
	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

// ServerConfig for external chaincode
type ServerConfig struct {
	CCID    string
	Address string
}

// SmartContract provides functions for managing rubber supply chain
type SmartContract struct {
	contractapi.Contract
}

// RubberCert describes basic details of rubber supply chain management
type AccountDetails struct {
	AccountId   string `json:"accountId"`
	Name        string `json:"name"`
	Id          string `json:"id"`
	PhoneNumber string `json:"phoneNumber"`
	Balance     int    `json:"balance"`
}

//To get History AccountId
type HistoryQueryResultAccount struct {
	Record    *AccountDetails `json:"AccountDetails"`
	AccountId string          `json:"AccountId"`
	Timestamp time.Time       `json:"timestamp"`
	IsDelete  bool            `json:"isDelete"`
}

// Transaction describes basic transaction
type TransactionDetails struct {
	FromAccountId   string `json:"fromAccountId"`
	Amount          int    `json:"amount"`
	ToAccountId     string `json:"toAccountId"`
	TransactionID   string `json:"transactionId"`
	TransactionDate string `json:"transactionDate"`
}

//function to check if account exixts or not.
func (s *SmartContract) AccountExists(ctx contractapi.TransactionContextInterface, accountId string) (bool, error) {
	AccountDetailsJSON, err := ctx.GetStub().GetState(accountId)
	if err != nil {
		return false, fmt.Errorf("failed to read from world state: %v", err)
	}

	return AccountDetailsJSON != nil, nil
}

//Generate Account
func (s *SmartContract) GenerateAccountDetails(ctx contractapi.TransactionContextInterface, accountId string, name string, id string, phoneNumber string, balance int) error {
	accountDetails := AccountDetails{
		AccountId:   accountId,
		Name:        name,
		Id:          id,
		PhoneNumber: phoneNumber,
		Balance:     balance,
	}

	accountDetailsAsBytes, _ := json.Marshal(accountDetails)

	return ctx.GetStub().PutState(accountId, accountDetailsAsBytes)
}

//query the account for API
func (s *SmartContract) QueryAccountApi(ctx contractapi.TransactionContextInterface, accountId string) (*AccountDetails, error) {

	AccountDetailsJSON, err := ctx.GetStub().GetState(accountId)
	if err != nil {
		return nil, fmt.Errorf("failed to read from world state: %v", err)
	}
	if AccountDetailsJSON == nil {
		return nil, fmt.Errorf("the asset %s does not exist", accountId)
	}

	var asset AccountDetails
	err = json.Unmarshal(AccountDetailsJSON, &asset)
	if err != nil {
		return nil, err
	}

	return &asset, nil
}

//query Account for internal usage
func (s *SmartContract) QueryAccount(ctx contractapi.TransactionContextInterface, accountId string) (*AccountDetails, error) {

	AccountDetailsJSON, err := ctx.GetStub().GetState(accountId)
	if err != nil {
		return nil, fmt.Errorf("failed to read from world state: %v", err)
	}
	if AccountDetailsJSON == nil {
		return nil, fmt.Errorf("the asset %s does not exist", accountId)
	}

	var asset AccountDetails
	err = json.Unmarshal(AccountDetailsJSON, &asset)
	if err != nil {
		return nil, err
	}

	return &asset, nil
}

//updateAccount
func (s *SmartContract) UpdateAccount(ctx contractapi.TransactionContextInterface, accountId string, name string, id string, phoneNumber string, balance int) (string, error) {
	exists, err := s.AccountExists(ctx, accountId)
	if err != nil {
		return "", err
	}
	if !exists {
		return "", fmt.Errorf("the account %s does not exist", accountId)
	}

	// overwritting original asset with new asset
	accountDetails := AccountDetails{
		AccountId:   accountId,
		Name:        name,
		Id:          id,
		PhoneNumber: phoneNumber,
		Balance:     balance,
	}

	accountDetailsAsBytes, _ := json.Marshal(accountDetails)

	return "data",ctx.GetStub().PutState(accountId, accountDetailsAsBytes)
}

//Generate Account
//code to check if the balance exists or not written to be reviewed
//code to update the balance account to be written , but to be reviewed

func (s *SmartContract) GenerateTransaction(ctx contractapi.TransactionContextInterface, fromAccountId string, amount int, toAccountId string, transactionID string, transactionDate string) (string, error) {

	//Code to check if fromAccountId the accounts exists or not
	existsfromAccountId, existsfromAccountIderr := s.AccountExists(ctx, fromAccountId)
	if existsfromAccountIderr != nil {
		return "error from existsfromAccountId", existsfromAccountIderr
	}

	//Code to check if toAccountId the accounts exists or not
	existstoAccountId, existstoAccountIderr := s.AccountExists(ctx, toAccountId)
	if existstoAccountIderr != nil {
		return "error from existstoAccountId", existstoAccountIderr
	}

	//To update the transaction in FromAccountId(Sender)
	if existsfromAccountId {
		accountDetailsFrom, accountDetailsFromerr := s.QueryAccount(ctx, fromAccountId)
		if accountDetailsFromerr != nil {
			return "error from accountDetailsFrom", accountDetailsFromerr
		}
		if accountDetailsFrom.Balance <= amount {
			return "Insufficient Balance", fmt.Errorf("Insufficient Balance")
		} else {
			//use update function to minus the amount
			fromAccountIdBalance := accountDetailsFrom.Balance
			fromAccountIdBalance = fromAccountIdBalance - amount

			// overwritting original asset with new asset
			accountDetailsFromOverridden := AccountDetails{
				AccountId:   accountDetailsFrom.AccountId,
				Name:        accountDetailsFrom.Name,
				Id:          accountDetailsFrom.Id,
				PhoneNumber: accountDetailsFrom.PhoneNumber,
				Balance:     fromAccountIdBalance,
			}

			accountDetailsAsBytes, _ := json.Marshal(accountDetailsFromOverridden)

			ctx.GetStub().PutState(fromAccountId, accountDetailsAsBytes)
		}
	}

	//Code to add amount to toamountId(Reciepent).
	if existstoAccountId {
		//code to check if the balance exists or not sld be written
		//First querying the account
		accountDetailsTo, accountIdToerr := s.QueryAccount(ctx, toAccountId)

		if accountIdToerr != nil {
			return "error", accountIdToerr
		} else {
			//code to update the balance account to be written

			//use update function to minus the amount
			toAccountIdBalance := accountDetailsTo.Balance
			toAccountIdBalance = toAccountIdBalance + amount

			// overwritting original asset with new asset
			accountDetailsToOverridden := AccountDetails{
				AccountId:   accountDetailsTo.AccountId,
				Name:        accountDetailsTo.Name,
				Id:          accountDetailsTo.Id,
				PhoneNumber: accountDetailsTo.PhoneNumber,
				Balance:     toAccountIdBalance,
			}

			accountDetailsAsBytes, _ := json.Marshal(accountDetailsToOverridden)
			//updating the data
			ctx.GetStub().PutState(fromAccountId, accountDetailsAsBytes)

			//transactionDetails
			transactionDetails := TransactionDetails{
				FromAccountId:   fromAccountId,
				Amount:          amount,
				ToAccountId:     toAccountId,
				TransactionID:   transactionID,
				TransactionDate: transactionDate,
			}

			TransactionBytes, err1 := json.Marshal(transactionDetails)
			if err1 != nil {
				fmt.Println("Couldn't marshal data from struct", err1)

			}
			transactionerr := ctx.GetStub().PutState(fromAccountId, TransactionBytes)
			if transactionerr != nil {
				fmt.Println("Could not save transaction data to ledger", transactionerr)
				return "could not save transaction data to ledger", fmt.Errorf("could not save transaction data to ledger")
			}

			//creating Composite Key index to be able to query based on it
			index := "toAccountIdfromAccountIdtransactionId_compositekey"
			FromAccountIdToAccountIdTransactionIdIndexKey, compositekeyerr := ctx.GetStub().CreateCompositeKey(index, []string{transactionDetails.FromAccountId, transactionDetails.ToAccountId, transactionDetails.TransactionID})
			if compositekeyerr != nil {
				fmt.Println("Could not index composite key for batchid and blockchainid", compositekeyerr)
				return "", fmt.Errorf("could not index composite key for FromAccountId ToAccountId TransactionID")
			}
			//  Save index entry to world state. Only the key name is needed, no need to store a duplicate copy of the asset.
			//  Note - passing a 'nil' value will effectively delete the key from state, therefore we pass null character as value
			value := []byte{0x00}
			ctx.GetStub().PutState(FromAccountIdToAccountIdTransactionIdIndexKey, value)
			fmt.Println("Successfully saved compositeKey of FromAccountId,ToAccountId,TransactionId")
		}

	} else {
		return "Transaction notStored in blockchain and account notUpdated with transaction amount ", fmt.Errorf("Transaction notStored in blockchain and account notUpdated with transaction amount")
	}
	return "Transaction stored in blockchain and account updated with transaction amount ", nil
}

//functions to query Transaction From fromAccountId, transactionId and toAccountId to be written needs to be changed
func (t *SmartContract) GetHistoryForTransactionaccountIdFrom(ctx contractapi.TransactionContextInterface, fromAccountId string) ([]TransactionDetails, error) {
	fmt.Println("TransactionId = ", fromAccountId)

	log.Println("TransactionId = ", fromAccountId)

	index := "toAccountIdfromAccountIdtransactionId_compositekey"

	transactionIdResultsIterator, err := ctx.GetStub().GetStateByPartialCompositeKey(index, []string{fromAccountId})

	if err != nil {

		return nil, err

	}

	defer transactionIdResultsIterator.Close()

	log.Println("transactionIdResultsIterator = ", transactionIdResultsIterator)

	var assets []TransactionDetails

	for transactionIdResultsIterator.HasNext() {

		responseRange, err := transactionIdResultsIterator.Next()

		if err != nil {

			return nil, err

		}

		_, compositeKeyParts, err := ctx.GetStub().SplitCompositeKey(responseRange.Key)

		if err != nil {

			return nil, err

		}

		if len(compositeKeyParts) > 1 {
			//transactionId is 2
			returnedAssetID := compositeKeyParts[0]

			log.Println("compositekey = ", compositeKeyParts)

			asset, err := ctx.GetStub().GetState(returnedAssetID)

			if err != nil {

				return nil, fmt.Errorf("failed to read from world state: %v", err)

			}

			if err != nil {

				return nil, err

			}

			log.Println("Asset = ", asset)
			var assetValue TransactionDetails
			if err := json.Unmarshal([]byte(asset), &assetValue); err != nil {
				panic(err)
			}

			log.Println("Asset value after unmarshaling = ", assetValue)
			assets = append(assets, assetValue)
		}

	}

	return assets, nil

}

//functions to query Transaction From toAccountId, transactionId and toAccountId to be written
func (t *SmartContract) GetHistoryForTransactionaccountIdTo(ctx contractapi.TransactionContextInterface, toAccountId string) ([]TransactionDetails, error) {
	fmt.Println("TransactionId = ", toAccountId)

	log.Println("TransactionId = ", toAccountId)

	index := "toAccountIdfromAccountIdtransactionId_compositekey"

	transactionIdResultsIterator, err := ctx.GetStub().GetStateByPartialCompositeKey(index, []string{toAccountId})

	if err != nil {

		return nil, err

	}

	defer transactionIdResultsIterator.Close()

	log.Println("transactionIdResultsIterator = ", transactionIdResultsIterator)

	var assets []TransactionDetails

	for transactionIdResultsIterator.HasNext() {

		responseRange, err := transactionIdResultsIterator.Next()

		if err != nil {

			return nil, err

		}

		_, compositeKeyParts, err := ctx.GetStub().SplitCompositeKey(responseRange.Key)

		if err != nil {

			return nil, err

		}

		if len(compositeKeyParts) > 1 {
			//transactionId is 2
			returnedAssetID := compositeKeyParts[1]

			log.Println("compositekey = ", compositeKeyParts)

			asset, err := ctx.GetStub().GetState(returnedAssetID)

			if err != nil {

				return nil, fmt.Errorf("failed to read from world state: %v", err)

			}

			if err != nil {

				return nil, err

			}

			log.Println("Asset = ", asset)
			var assetValue TransactionDetails
			if err := json.Unmarshal([]byte(asset), &assetValue); err != nil {
				panic(err)
			}

			log.Println("Asset value after unmarshaling = ", assetValue)
			assets = append(assets, assetValue)
		}

	}

	return assets, nil

}

func (t *SmartContract) GetHistoryForTransactionByTransactionId(ctx contractapi.TransactionContextInterface, transactionId string) ([]TransactionDetails, error) {
	fmt.Println("TransactionId = ", transactionId)

	log.Println("TransactionId = ", transactionId)

	index := "toAccountIdfromAccountIdtransactionId_compositekey"

	transactionIdResultsIterator, err := ctx.GetStub().GetStateByPartialCompositeKey(index, []string{transactionId})

	if err != nil {

		return nil, err

	}

	defer transactionIdResultsIterator.Close()

	log.Println("transactionIdResultsIterator = ", transactionIdResultsIterator)

	var assets []TransactionDetails

	for transactionIdResultsIterator.HasNext() {

		responseRange, err := transactionIdResultsIterator.Next()

		if err != nil {

			return nil, err

		}

		_, compositeKeyParts, err := ctx.GetStub().SplitCompositeKey(responseRange.Key)

		if err != nil {

			return nil, err

		}

		if len(compositeKeyParts) > 1 {
			//transactionId is 2
			returnedAssetID := compositeKeyParts[2]

			log.Println("compositekey = ", compositeKeyParts)

			asset, err := ctx.GetStub().GetState(returnedAssetID)

			if err != nil {

				return nil, fmt.Errorf("failed to read from world state: %v", err)

			}

			if err != nil {

				return nil, err

			}

			log.Println("Asset = ", asset)
			var assetValue TransactionDetails
			if err := json.Unmarshal([]byte(asset), &assetValue); err != nil {
				panic(err)
			}

			log.Println("Asset value after unmarshaling = ", assetValue)
			assets = append(assets, assetValue)
		}

	}

	return assets, nil

}

func (t *SmartContract) GetHistoryForAccount(ctx contractapi.TransactionContextInterface, AccountId string) ([]HistoryQueryResultAccount, error) {
	log.Printf("GetAssetHistory: batchID %v", AccountId)

	resultsIterator, err := ctx.GetStub().GetHistoryForKey(AccountId)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	var records []HistoryQueryResultAccount
	for resultsIterator.HasNext() {
		response, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}

		var asset AccountDetails
		fmt.Println("Asset = ", asset)
		log.Println("asset = ", asset)
		if len(response.Value) > 0 {
			err = json.Unmarshal(response.Value, &asset)
			if err != nil {
				return nil, err
			}
		} else {
			asset = AccountDetails{
				AccountId: AccountId,
			}
		}

		timestamp, err := ptypes.Timestamp(response.Timestamp)
		if err != nil {
			return nil, err
		}

		record := HistoryQueryResultAccount{
			AccountId: AccountId,
			Timestamp: timestamp,
			Record:    &asset,
			IsDelete:  response.IsDelete,
		}
		records = append(records, record)
	}

	fmt.Println("records = ", records)
	log.Println("Records = ", records)

	return records, nil

}

func main() {
	// smartContract := new(SmartContract)
	config := ServerConfig{
		CCID:    os.Getenv("CHAINCODE_ID"),
		Address: os.Getenv("CHAINCODE_SERVER_ADDRESS"),
	}
	chaincode, err := contractapi.NewChaincode(&SmartContract{})

	if err != nil {
		panic(err.Error())
	}

	server := &shim.ChaincodeServer{
		CCID:     config.CCID,
		Address:  config.Address,
		CC:       chaincode,
		TLSProps: getTLSProperties(),
	}

	if err := server.Start(); err != nil {
		log.Panicf("error starting asset-transfer-basic chaincode: %s", err)
	}
}

func getTLSProperties() shim.TLSProperties {
	// Check if chaincode is TLS enabled
	tlsDisabledStr := getEnvOrDefault("CHAINCODE_TLS_DISABLED", "true")
	key := getEnvOrDefault("CHAINCODE_TLS_KEY", "")
	cert := getEnvOrDefault("CHAINCODE_TLS_CERT", "")
	clientCACert := getEnvOrDefault("CHAINCODE_CLIENT_CA_CERT", "")

	// convert tlsDisabledStr to boolean
	tlsDisabled := getBoolOrDefault(tlsDisabledStr, false)
	var keyBytes, certBytes, clientCACertBytes []byte
	var err error

	if !tlsDisabled {
		keyBytes, err = os.ReadFile(key)
		if err != nil {
			log.Panicf("error while reading the crypto file: %s", err)
		}
		certBytes, err = os.ReadFile(cert)
		if err != nil {
			log.Panicf("error while reading the crypto file: %s", err)
		}
	}
	// Did not request for the peer cert verification
	if clientCACert != "" {
		clientCACertBytes, err = os.ReadFile(clientCACert)
		if err != nil {
			log.Panicf("error while reading the crypto file: %s", err)
		}
	}

	return shim.TLSProperties{
		Disabled:      tlsDisabled,
		Key:           keyBytes,
		Cert:          certBytes,
		ClientCACerts: clientCACertBytes,
	}
}

func getEnvOrDefault(env, defaultVal string) string {
	value, ok := os.LookupEnv(env)
	if !ok {
		value = defaultVal
	}
	return value
}

// #Note that the method returns default value if the string
// cannot be parsed!
func getBoolOrDefault(value string, defaultVal bool) bool {
	parsed, err := strconv.ParseBool(value)
	if err != nil {
		return defaultVal
	}
	return parsed
}




















































