package chaincode

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"log"

	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

const assetCollection = "assetCollection"
const transferAgreementObjectType = "transferAgreement"

// SmartContract of this fabric sample
type SmartContract struct {
	contractapi.Contract
}

// AccountDetails describes main Account Details that are visible to all organizations
type AccountDetails struct {
	AccountId   string `json:"AccountId"`
	Name        string `json:"Name"`
	Id          string `json:"Id"`
	PhoneNumber string `json:"PhoneNumber"`
	Balance     int    `json:"Balance"`
}

//To get History AccountId
type HistoryQueryResultAccount struct {
	Record    *AccountDetails `json:"AccountDetails"`
	AccountId string          `json:"AccountId"`
	Timestamp time.Time       `json:"timestamp"`
	IsDelete  bool            `json:"isDelete"`
}

// Transaction describes basic transaction
type TransactionDetails struct {
	FromAccountId   string `json:"FromAccountId"`
	Amount          int    `json:"Amount"`
	ToAccountId     string `json:"ToAccountId"`
	TransactionID   string `json:"TransactionID"`
	TransactionDate string `json:"TransactionDate"`
}

// AssetPrivateDetails describes details that are private to owners
type AssetPrivateDetails struct {
	AccountId             string `json:"AccountId"`
	UpdatedBalance int    `json:"UpdatedBalance"`
}

func (s *SmartContract) GenerateAccountDetails(ctx contractapi.TransactionContextInterface) error {

	// Get new asset from transient map
	transientMap, err := ctx.GetStub().GetTransient()
	if err != nil {
		return fmt.Errorf("error getting transient: %v", err)
	}

	// Asset properties are private, therefore they get passed in transient field, instead of func args
	transientAssetJSON, ok := transientMap["asset_properties"]
	if !ok {
		// log error to stdout
		return fmt.Errorf("asset not found in the transient map input")
	}

	type assetTransientInput struct {
		AccountId   string `json:"AccountId"`
		Name        string `json:"Name"`
		Id          string `json:"Id"`
		PhoneNumber string `json:"PhoneNumber"`
		Balance     int    `json:"Balance"`
	}

	var assetInput assetTransientInput
	err = json.Unmarshal(transientAssetJSON, &assetInput)
	if err != nil {
		return fmt.Errorf("failed to unmarshal JSON: %v", err)
	}

	if len(assetInput.AccountId) == 0 {
		return fmt.Errorf("objectType field must be a non-empty string")
	}
	if len(assetInput.Name) == 0 {
		return fmt.Errorf("assetID field must be a non-empty string")
	}
	if len(assetInput.Id) == 0 {
		return fmt.Errorf("color field must be a non-empty string")
	}
	if len(assetInput.PhoneNumber) == 0 {
		return fmt.Errorf("color field must be a non-empty string")
	}
	if len(assetInput.Balance) <= 0 {
		return fmt.Errorf("balance field must be a positive integer")
	}

	// Check if asset already exists
	assetAsBytes, err := ctx.GetStub().GetPrivateData(assetCollection, assetInput.AccountId)
	if err != nil {
		return fmt.Errorf("failed to get asset: %v", err)
	} else if assetAsBytes != nil {
		fmt.Println("Asset already exists: " + assetInput.AccountId)
		return fmt.Errorf("this asset already exists: " + assetInput.AccountId)
	}

	// Get ID of submitting client identity
	clientID, err := submittingClientIdentity(ctx)
	if err != nil {
		return err
	}

	// Verify that the client is submitting request to peer in their organization
	// This is to ensure that a client from another org doesn't attempt to read or
	// write private data from this peer.
	err = verifyClientOrgMatchesPeerOrg(ctx)
	if err != nil {
		return fmt.Errorf("CreateAsset cannot be performed: Error %v", err)
	}

	// Make submitting client the owner
	asset := Asset{
		AccountId:  assetInput.AccountId,
		Name:    assetInput.Name,
		Id: assetInput.Id,
		PhoneNumber:  assetInput.PhoneNumber,
		Balance: assetInput.Balance,
	}
	assetJSONasBytes, err := json.Marshal(asset)
	if err != nil {
		return fmt.Errorf("failed to marshal asset into JSON: %v", err)
	}

	// Save asset to private data collection
	// Typical logger, logs to stdout/file in the fabric managed docker container, running this chaincode
	// Look for container name like dev-peer0.org1.example.com-{chaincodename_version}-xyz
	log.Printf("CreateAsset Put: collection %v, ID %v, owner %v", assetCollection, assetInput.AccountId, clientID)

	err = ctx.GetStub().PutPrivateData(assetCollection, assetInput.AccountId, assetJSONasBytes)
	if err != nil {
		return fmt.Errorf("failed to put asset into private data collecton: %v", err)
	}

	// Save asset details to collection visible to owning organization
	assetPrivateDetails := AssetPrivateDetails{
		AccountId:             assetInput.AccountId,
		Balance: 				assetInput.Balance,
	}

	assetPrivateDetailsAsBytes, err := json.Marshal(assetPrivateDetails) // marshal asset details to JSON
	if err != nil {
		return fmt.Errorf("failed to marshal into JSON: %v", err)
	}

	// Get collection name for this organization.
	orgCollection, err := getCollectionName(ctx)
	if err != nil {
		return fmt.Errorf("failed to infer private collection name for the org: %v", err)
	}

	// Put asset appraised value into owners org specific private data collection
	log.Printf("Put: collection %v, ID %v", orgCollection, assetInput.AccountId)
	err = ctx.GetStub().PutPrivateData(orgCollection, assetInput.AccountId, assetPrivateDetailsAsBytes)
	if err != nil {
		return fmt.Errorf("failed to put asset private details: %v", err)
	}
	return nil
}

func (s *SmartContract) QueryAccountApi(ctx contractapi.TransactionContextInterface, AccountId string) (string, error) {
	value, err := ctx.GetStub().GetPrivateData(AccountId)
	if err != nil {
		return "", fmt.Errorf("failed to read from private data collection: %v", err)
	}
	if value == nil {
		return "", fmt.Errorf("data does not exist in the private data collection")
	}
	return string(value), nil
}


// func (s *SmartContract) QueryAccountApi1(ctx contractapi.TransactionContextInterface, accountId string) error {

// 	// Check 1: verify that the transfer is being initiatied by the owner

// 	// Get ID of submitting client identity
// 	clientID, err := submittingClientIdentity(ctx)
// 	if err != nil {
// 		return err
// 	}

// 	if clientID != owner {
// 		return fmt.Errorf("error: submitting client identity does not own asset")
// 	}

// 	// Check 2: verify that the buyer has agreed to the appraised value

// 	// Get collection names
// 	collectionOwner, err := getCollectionName(ctx) // get owner collection from caller identity
// 	if err != nil {
// 		return fmt.Errorf("failed to infer private collection name for the org: %v", err)
// 	}

// 	collectionBuyer := buyerMSP + "PrivateCollection" // get buyers collection

// 	// Get hash of owners agreed to value
// 	ownerAppraisedValueHash, err := ctx.GetStub().GetPrivateDataHash(accountId)
// 	if err != nil {
// 		return fmt.Errorf("failed to get hash of appraised value from owners collection %v: %v", accountId, err)
// 	}
// 	if ownerAppraisedValueHash == nil {
// 		return fmt.Errorf("hash of appraised value for %v does not exist in collection %v", accountId)
// 	}

// 	// Get hash of buyers agreed to value
// 	buyerAppraisedValueHash, err := ctx.GetStub().GetPrivateDataHash(accountId)
// 	if err != nil {
// 		return fmt.Errorf("failed to get hash of appraised value from buyer collection %v: %v", accountId, err)
// 	}
// 	if buyerAppraisedValueHash == nil {
// 		return fmt.Errorf("hash of appraised value for %v does not exist in collection %v. AgreeToTransfer must be called by the buyer first", accountId)
// 	}

// 	// Verify that the two hashes match
// 	if !bytes.Equal(ownerAppraisedValueHash, buyerAppraisedValueHash) {
// 		return fmt.Errorf("hash for appraised value for owner %x does not value for seller %x", ownerAppraisedValueHash, buyerAppraisedValueHash)
// 	}

// 	return nil
// }

func (s *SmartContract) GenerateTransaction(ctx contractapi.TransactionContextInterface) error {

	transientMap, err := ctx.GetStub().GetTransient()
	if err != nil {
		return fmt.Errorf("error getting transient %v", err)
	}

	// Asset properties are private, therefore they get passed in transient field
	transientTransferJSON, ok := transientMap["asset_owner"]
	if !ok {
		return fmt.Errorf("asset owner not found in the transient map")
	}

	type assetTransferTransientInput struct {
		AccountId       string `json:"AccountId"`
		ToAccountMSP string `json:"ToAccountMSP"`
	}

	var assetTransferInput assetTransferTransientInput
	err = json.Unmarshal(transientTransferJSON, &assetTransferInput)
	if err != nil {
		return fmt.Errorf("failed to unmarshal JSON: %v", err)
	}

	if len(assetTransferInput.AccountId) == 0 {
		return fmt.Errorf("AccountId field must be a non-empty string")
	}
	if len(assetTransferInput.ToAccountMSP) == 0 {
		return fmt.Errorf("ToAccountId field must be a non-empty string")
	}
	log.Printf("TransferAsset: verify asset exists ID %v", assetTransferInput.AccountId)
	// Read asset from the private data collection
	asset, err := s.ReadAsset(ctx, assetTransferInput.AccountId)
	if err != nil {
		return fmt.Errorf("error reading asset: %v", err)
	}
	if asset == nil {
		return fmt.Errorf("%v does not exist", assetTransferInput.AccountId)
	}
	// Verify that the client is submitting request to peer in their organization
	err = verifyClientOrgMatchesPeerOrg(ctx)
	if err != nil {
		return fmt.Errorf("TransferAsset cannot be performed: Error %v", err)
	}

	// Verify transfer details and transfer owner
	err = s.verifyAgreement(ctx, assetTransferInput.AccountId, asset.FromAccountId, assetTransferInput.ToAccountMSP)
	if err != nil {
		return fmt.Errorf("failed transfer verification: %v", err)
	}

	transferAgreement, err := s.ReadTransferAgreement(ctx, assetTransferInput.AccountId)
	if err != nil {
		return fmt.Errorf("failed ReadTransferAgreement to find buyerID: %v", err)
	}
	if transferAgreement.ToAccountId == "" {
		return fmt.Errorf("BuyerID not found in TransferAgreement for %v", assetTransferInput.AccountId)
	}

	// Transfer asset in private data collection to new owner
	asset.AccountId = transferAgreement.ToAccountId

	assetJSONasBytes, err := json.Marshal(asset)
	if err != nil {
		return fmt.Errorf("failed marshalling asset %v: %v", assetTransferInput.AccountId, err)
	}

	log.Printf("TransferAsset Put: collection %v, ID %v", assetCollection, assetTransferInput.AccountId)
	err = ctx.GetStub().PutPrivateData(assetCollection, assetTransferInput.AccountId, assetJSONasBytes) //rewrite the asset
	if err != nil {
		return err
	}

	// Get collection name for this organization
	ownersCollection, err := getCollectionName(ctx)
	if err != nil {
		return fmt.Errorf("failed to infer private collection name for the org: %v", err)
	}

	// Delete the asset appraised value from this organization's private data collection
	err = ctx.GetStub().DelPrivateData(ownersCollection, assetTransferInput.AccountId)
	if err != nil {
		return err
	}

	// Delete the transfer agreement from the asset collection
	transferAgreeKey, err := ctx.GetStub().CreateCompositeKey(transferAgreementObjectType, []string{assetTransferInput.AccountId})
	if err != nil {
		return fmt.Errorf("failed to create composite key: %v", err)
	}

	err = ctx.GetStub().DelPrivateData(assetCollection, transferAgreeKey)
	if err != nil {
		return err
	}

	return nil

}


func (s *SmartContract) GetHistoryForTransactionaccountIdFrom(ctx contractapi.TransactionContextInterface, FromAccountId string, privateDataCollection string) ([]HistoryQueryResultAccount, error) {
	// Retrieve the private data associated with the asset from the specified collection
	privateData, err := ctx.GetStub().GetPrivateData(privateDataCollection, FromAccountId)
	if err != nil {
		return nil, fmt.Errorf("failed to get private data from the collection: %v", err)
	}
	if privateData == nil {
		return nil, fmt.Errorf("asset not found in the private data collection")
	}

	// Retrieve the public data (state history) associated with the asset from the shared ledger
	iterator, err := ctx.GetStub().GetHistoryForKey(FromAccountId)
	if err != nil {
		return nil, fmt.Errorf("failed to get asset's history from the shared ledger: %v", err)
	}
	defer iterator.Close()

	// Iterate over the history and construct the asset's history records
	var assetHistory []HistoryQueryResultAccount
	for iterator.HasNext() {
		history, err := iterator.Next()
		if err != nil {
			return nil, fmt.Errorf("failed to iterate through asset's history: %v", err)
		}

		assetHistory = append(assetHistory, HistoryQueryResultAccount{
			AccountId:      history.AccountId,
			Timestamp :     history.Timestamp,
			IsDelete: history.IsDelete,
		})
	}

	return assetHistory, nil
}


func (s *SmartContract) GetHistoryForTransactionaccountIdTo(ctx contractapi.TransactionContextInterface, ToAccountId string, privateDataCollection string) ([]HistoryQueryResultAccount, error) {
	// Retrieve the private data associated with the asset from the specified collection
	privateData, err := ctx.GetStub().GetPrivateData(privateDataCollection, ToAccountId)
	if err != nil {
		return nil, fmt.Errorf("failed to get private data from the collection: %v", err)
	}
	if privateData == nil {
		return nil, fmt.Errorf("asset not found in the private data collection")
	}

	// Retrieve the public data (state history) associated with the asset from the shared ledger
	iterator, err := ctx.GetStub().GetHistoryForKey(ToAccountId)
	if err != nil {
		return nil, fmt.Errorf("failed to get asset's history from the shared ledger: %v", err)
	}
	defer iterator.Close()

	// Iterate over the history and construct the asset's history records
	var assetHistory []HistoryQueryResultAccount
	for iterator.HasNext() {
		history, err := iterator.Next()
		if err != nil {
			return nil, fmt.Errorf("failed to iterate through asset's history: %v", err)
		}

		assetHistory = append(assetHistory, HistoryQueryResultAccount{
			AccountId:      history.AccountId,
			Timestamp :     history.Timestamp,
			IsDelete: history.IsDelete,
		})
	}

	return assetHistory, nil
}

func (s *SmartContract) GetHistoryForTransactionByTransactionId(ctx contractapi.TransactionContextInterface, TransactionID string, privateDataCollection string) ([]HistoryQueryResultAccount, error) {
	// Retrieve the private data associated with the asset from the specified collection
	privateData, err := ctx.GetStub().GetPrivateData(privateDataCollection, TransactionID)
	if err != nil {
		return nil, fmt.Errorf("failed to get private data from the collection: %v", err)
	}
	if privateData == nil {
		return nil, fmt.Errorf("asset not found in the private data collection")
	}

	// Retrieve the public data (state history) associated with the asset from the shared ledger
	iterator, err := ctx.GetStub().GetHistoryForKey(TransactionID)
	if err != nil {
		return nil, fmt.Errorf("failed to get asset's history from the shared ledger: %v", err)
	}
	defer iterator.Close()

	// Iterate over the history and construct the asset's history records
	var assetHistory []HistoryQueryResultAccount
	for iterator.HasNext() {
		history, err := iterator.Next()
		if err != nil {
			return nil, fmt.Errorf("failed to iterate through asset's history: %v", err)
		}

		assetHistory = append(assetHistory, HistoryQueryResultAccount{
			AccountId:      history.AccountId,
			Timestamp :     history.Timestamp,
			IsDelete: history.IsDelete,
		})
	}

	return assetHistory, nil
}


func (s *SmartContract) GetHistoryForAccount(ctx contractapi.TransactionContextInterface, AccountId string, privateDataCollection string) ([]HistoryQueryResultAccount, error) {
	// Retrieve the private data associated with the asset from the specified collection
	privateData, err := ctx.GetStub().GetPrivateData(privateDataCollection, AccountId)
	if err != nil {
		return nil, fmt.Errorf("failed to get private data from the collection: %v", err)
	}
	if privateData == nil {
		return nil, fmt.Errorf("asset not found in the private data collection")
	}

	// Retrieve the public data (state history) associated with the asset from the shared ledger
	iterator, err := ctx.GetStub().GetHistoryForKey(AccountId)
	if err != nil {
		return nil, fmt.Errorf("failed to get asset's history from the shared ledger: %v", err)
	}
	defer iterator.Close()

	// Iterate over the history and construct the asset's history records
	var assetHistory []HistoryQueryResultAccount
	for iterator.HasNext() {
		history, err := iterator.Next()
		if err != nil {
			return nil, fmt.Errorf("failed to iterate through asset's history: %v", err)
		}

		assetHistory = append(assetHistory, HistoryQueryResultAccount{
			AccountId:      history.AccountId,
			Timestamp :     history.Timestamp,
			IsDelete: history.IsDelete,
		})
	}

	return assetHistory, nil
}

func main() {
	smartContract := new(SmartContract)

	cc, err := contractapi.NewChaincode(smartContract)

	if err != nil {
		panic(err.Error())
	}

	if err := cc.Start(); err != nil {
		panic(err.Error())
	}
}