export PATH=/home/rakeshdms/fabric-components/binV2.2/fabric-samples/bin:$PATH
createCertForSysAdmin() {
    echo
    echo "Enroll CA admin of SysAdmin"
    echo
    mkdir -p ../organizations/peerOrganizations/sysadmin.asset.com/
    export FABRIC_CA_CLIENT_HOME=${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/

    fabric-ca-client enroll -u https://admin:adminpw@localhost:7054 --caname ca.sysadmin.asset.com --tls.certfiles ${PWD}/../organizations/fabric-ca/sysadmin/tls-cert.pem

    echo 'NodeOUs:
  Enable: true
  ClientOUIdentifier:
    Certificate: cacerts/localhost-7054-ca-sysadmin-asset-com.pem
    OrganizationalUnitIdentifier: client
  PeerOUIdentifier:
    Certificate: cacerts/localhost-7054-ca-sysadmin-asset-com.pem
    OrganizationalUnitIdentifier: peer
  AdminOUIdentifier:
    Certificate: cacerts/localhost-7054-ca-sysadmin-asset-com.pem
    OrganizationalUnitIdentifier: admin
  OrdererOUIdentifier:
    Certificate: cacerts/localhost-7054-ca-sysadmin-asset-com.pem
    OrganizationalUnitIdentifier: orderer' >${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/msp/config.yaml

    echo
    echo "Register peer0.sysadmin"
    echo

    fabric-ca-client register --caname ca.sysadmin.asset.com --id.name peer0 --id.secret peer0pw --id.type peer --tls.certfiles ${PWD}/../organizations/fabric-ca/sysadmin/tls-cert.pem

    echo
    echo "Register peer1.sysadmin"
    echo

    fabric-ca-client register --caname ca.sysadmin.asset.com --id.name peer1 --id.secret peer1pw --id.type peer --tls.certfiles ${PWD}/../organizations/fabric-ca/sysadmin/tls-cert.pem

    echo
    echo "Register user1.sysadmin"
    echo

    fabric-ca-client register --caname ca.sysadmin.asset.com --id.name user1 --id.secret user1pw --id.type client --tls.certfiles ${PWD}/../organizations/fabric-ca/sysadmin/tls-cert.pem

    echo
    echo "Register admin.sysadmin"
    echo

    fabric-ca-client register --caname ca.sysadmin.asset.com --id.name org1admin --id.secret adminpw --id.type admin --tls.certfiles ${PWD}/../organizations/fabric-ca/sysadmin/tls-cert.pem

    mkdir -p ../organizations/peerOrganizations/sysadmin.asset.com/peers
    
    # -----------------------------------------------------------------------------------
    # Peer0
    mkdir -p ../organizations/peerOrganizations/sysadmin.asset.com/peers/peer0.sysadmin.asset.com

    echo
    echo "Generate Peer0 MSP"
    echo

    fabric-ca-client enroll -u https://peer0:peer0pw@localhost:7054 --caname ca.sysadmin.asset.com -M ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer0.sysadmin.asset.com/msp --csr.hosts peer0.sysadmin.asset.com --tls.certfiles ${PWD}/../organizations/fabric-ca/sysadmin/tls-cert.pem

    cp ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/msp/config.yaml ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer0.sysadmin.asset.com/msp/config.yaml

    echo
    echo "Generate Peer0 TLS-CERTs"
    echo

    fabric-ca-client enroll -u https://peer0:peer0pw@localhost:7054 --caname ca.sysadmin.asset.com -M ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer0.sysadmin.asset.com/tls --enrollment.profile tls --csr.hosts peer0.sysadmin.asset.com --csr.hosts localhost --tls.certfiles ${PWD}/../organizations/fabric-ca/sysadmin/tls-cert.pem

    cp ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer0.sysadmin.asset.com/tls/tlscacerts/* ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer0.sysadmin.asset.com/tls/ca.crt
    cp ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer0.sysadmin.asset.com/tls/signcerts/* ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer0.sysadmin.asset.com/tls/server.crt
    cp ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer0.sysadmin.asset.com/tls/keystore/* ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer0.sysadmin.asset.com/tls/server.key

    mkdir ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/msp/tlscacerts
    cp ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer0.sysadmin.asset.com/tls/tlscacerts/* ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/msp/tlscacerts/ca.crt

    mkdir ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/tlsca
    cp ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer0.sysadmin.asset.com/tls/tlscacerts/* ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/tlsca/tlsca.sysadmin.asset.com-cert.pem

    mkdir ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/ca
    cp ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer0.sysadmin.asset.com/msp/cacerts/* ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/ca/ca.sysadmin.asset.com-cert.pem

    # -----------------------------------------------------------------------------------
    # Peer1
    mkdir -p ../organizations/peerOrganizations/sysadmin.asset.com/peers/peer1.sysadmin.asset.com

    echo
    echo "Generate Peer1 MSP"
    echo

    fabric-ca-client enroll -u https://peer1:peer1pw@localhost:7054 --caname ca.sysadmin.asset.com -M ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer1.sysadmin.asset.com/msp --csr.hosts peer1.sysadmin.asset.com --tls.certfiles ${PWD}/../organizations/fabric-ca/sysadmin/tls-cert.pem

    cp ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/msp/config.yaml ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer1.sysadmin.asset.com/msp/config.yaml

    echo
    echo "Generate Peer1 TLS-CERTs"
    echo

    fabric-ca-client enroll -u https://peer1:peer1pw@localhost:7054 --caname ca.sysadmin.asset.com -M ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer1.sysadmin.asset.com/tls --enrollment.profile tls --csr.hosts peer1.sysadmin.asset.com --csr.hosts localhost --tls.certfiles ${PWD}/../organizations/fabric-ca/sysadmin/tls-cert.pem

    cp ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer1.sysadmin.asset.com/tls/tlscacerts/* ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer1.sysadmin.asset.com/tls/ca.crt
    cp ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer1.sysadmin.asset.com/tls/signcerts/* ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer1.sysadmin.asset.com/tls/server.crt
    cp ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer1.sysadmin.asset.com/tls/keystore/* ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer1.sysadmin.asset.com/tls/server.key

    # mkdir ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/msp/tlscacerts
    # cp ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer1.sysadmin.asset.com/tls/keystore/* ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/msp/tlscacerts/ca.crt

    # mkdir ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer1.sysadmin.asset.com/tlsca
    # cp ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer1.sysadmin.asset.com/tls/tlscacerts/* ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/tlsca/tlsca.sysadmin.asset.com-cert.pem

    # mkdir ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/ca
    # cp ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/peers/peer1.sysadmin.asset.com/msp/cacerts/* ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/ca/ca.sysadmin.asset.com-cert.pem
    
    # ------------------------------------------------------------------------------------------
    mkdir -p ../organizations/peerOrganizations/sysadmin.asset.com/users
    mkdir -p ../organizations/peerOrganizations/sysadmin.asset.com/users/User1@sysadmin.asset.com

    echo
    echo "Generate User1 MSP"
    echo
    fabric-ca-client enroll -u https://user1:user1pw@localhost:7054 --caname ca.sysadmin.asset.com -M ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/users/User1@sysadmin.asset.com/msp --tls.certfiles ${PWD}/../organizations/fabric-ca/sysadmin/tls-cert.pem

    mkdir -p ../organizations/peerOrganizations/sysadmin.asset.com/users/Admin@sysadmin.asset.com

    echo
    echo "Generate SysAdmin Admin MSP"
    echo

    fabric-ca-client enroll -u https://org1admin:adminpw@localhost:7054 --caname ca.sysadmin.asset.com -M ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/users/Admin@sysadmin.asset.com/msp --tls.certfiles ${PWD}/../organizations/fabric-ca/sysadmin/tls-cert.pem

    cp ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/msp/config.yaml ${PWD}/../organizations/peerOrganizations/sysadmin.asset.com/users/Admin@sysadmin.asset.com/msp/config.yaml
}

createCertForIssuer() {
    echo
    echo "Enroll CA admin of Issuer"
    echo
    mkdir -p ../organizations/peerOrganizations/issuer.asset.com/
    export FABRIC_CA_CLIENT_HOME=${PWD}/../organizations/peerOrganizations/issuer.asset.com/

    fabric-ca-client enroll -u https://admin:adminpw@localhost:8054 --caname ca.issuer.asset.com --tls.certfiles ${PWD}/../organizations/fabric-ca/issuer/tls-cert.pem

    echo 'NodeOUs:
  Enable: true
  ClientOUIdentifier:
    Certificate: cacerts/localhost-8054-ca-issuer-asset-com.pem
    OrganizationalUnitIdentifier: client
  PeerOUIdentifier:
    Certificate: cacerts/localhost-8054-ca-issuer-asset-com.pem
    OrganizationalUnitIdentifier: peer
  AdminOUIdentifier:
    Certificate: cacerts/localhost-8054-ca-issuer-asset-com.pem
    OrganizationalUnitIdentifier: admin
  OrdererOUIdentifier:
    Certificate: cacerts/localhost-8054-ca-issuer-asset-com.pem
    OrganizationalUnitIdentifier: orderer' >${PWD}/../organizations/peerOrganizations/issuer.asset.com/msp/config.yaml

    echo
    echo "Register peer0.issuer"
    echo

    fabric-ca-client register --caname ca.issuer.asset.com --id.name peer0 --id.secret peer0pw --id.type peer --tls.certfiles ${PWD}/../organizations/fabric-ca/issuer/tls-cert.pem

    echo
    echo "Register peer1.issuer"
    echo

    fabric-ca-client register --caname ca.issuer.asset.com --id.name peer1 --id.secret peer1pw --id.type peer --tls.certfiles ${PWD}/../organizations/fabric-ca/issuer/tls-cert.pem

    echo
    echo "Register user1.issuer"
    echo

    fabric-ca-client register --caname ca.issuer.asset.com --id.name user1 --id.secret user1pw --id.type client --tls.certfiles ${PWD}/../organizations/fabric-ca/issuer/tls-cert.pem

    echo
    echo "Register admin.issuer"
    echo

    fabric-ca-client register --caname ca.issuer.asset.com --id.name org2admin --id.secret adminpw --id.type admin --tls.certfiles ${PWD}/../organizations/fabric-ca/issuer/tls-cert.pem

    mkdir -p ../organizations/peerOrganizations/issuer.asset.com/peers
    
    # -----------------------------------------------------------------------------------
    # Peer0
    mkdir -p ../organizations/peerOrganizations/issuer.asset.com/peers/peer0.issuer.asset.com

    echo
    echo "Generate Peer0 MSP"
    echo

    fabric-ca-client enroll -u https://peer0:peer0pw@localhost:8054 --caname ca.issuer.asset.com -M ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer0.issuer.asset.com/msp --csr.hosts peer0.issuer.asset.com --tls.certfiles ${PWD}/../organizations/fabric-ca/issuer/tls-cert.pem

    cp ${PWD}/../organizations/peerOrganizations/issuer.asset.com/msp/config.yaml ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer0.issuer.asset.com/msp/config.yaml

    echo
    echo "Generate Peer0 TLS-CERTs"
    echo

    fabric-ca-client enroll -u https://peer0:peer0pw@localhost:8054 --caname ca.issuer.asset.com -M ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer0.issuer.asset.com/tls --enrollment.profile tls --csr.hosts peer0.issuer.asset.com --csr.hosts localhost --tls.certfiles ${PWD}/../organizations/fabric-ca/issuer/tls-cert.pem

    cp ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer0.issuer.asset.com/tls/tlscacerts/* ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer0.issuer.asset.com/tls/ca.crt
    cp ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer0.issuer.asset.com/tls/signcerts/* ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer0.issuer.asset.com/tls/server.crt
    cp ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer0.issuer.asset.com/tls/keystore/* ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer0.issuer.asset.com/tls/server.key

    mkdir ${PWD}/../organizations/peerOrganizations/issuer.asset.com/msp/tlscacerts
    cp ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer0.issuer.asset.com/tls/tlscacerts/* ${PWD}/../organizations/peerOrganizations/issuer.asset.com/msp/tlscacerts/ca.crt

    mkdir ${PWD}/../organizations/peerOrganizations/issuer.asset.com/tlsca
    cp ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer0.issuer.asset.com/tls/tlscacerts/* ${PWD}/../organizations/peerOrganizations/issuer.asset.com/tlsca/tlsca.issuer.asset.com-cert.pem

    mkdir ${PWD}/../organizations/peerOrganizations/issuer.asset.com/ca
    cp ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer0.issuer.asset.com/msp/cacerts/* ${PWD}/../organizations/peerOrganizations/issuer.asset.com/ca/ca.issuer.asset.com-cert.pem

    # -----------------------------------------------------------------------------------
    # Peer1
    mkdir -p ../organizations/peerOrganizations/issuer.asset.com/peers/peer1.issuer.asset.com

    echo
    echo "Generate Peer1 MSP"
    echo

    fabric-ca-client enroll -u https://peer1:peer1pw@localhost:8054 --caname ca.issuer.asset.com -M ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer1.issuer.asset.com/msp --csr.hosts peer1.issuer.asset.com --tls.certfiles ${PWD}/../organizations/fabric-ca/issuer/tls-cert.pem

    cp ${PWD}/../organizations/peerOrganizations/issuer.asset.com/msp/config.yaml ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer1.issuer.asset.com/msp/config.yaml

    echo
    echo "Generate Peer1 TLS-CERTs"
    echo

    fabric-ca-client enroll -u https://peer1:peer1pw@localhost:8054 --caname ca.issuer.asset.com -M ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer1.issuer.asset.com/tls --enrollment.profile tls --csr.hosts peer1.issuer.asset.com --csr.hosts localhost --tls.certfiles ${PWD}/../organizations/fabric-ca/issuer/tls-cert.pem

    cp ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer1.issuer.asset.com/tls/tlscacerts/* ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer1.issuer.asset.com/tls/ca.crt
    cp ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer1.issuer.asset.com/tls/signcerts/* ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer1.issuer.asset.com/tls/server.crt
    cp ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer1.issuer.asset.com/tls/keystore/* ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer1.issuer.asset.com/tls/server.key

    # mkdir ${PWD}/../organizations/peerOrganizations/issuer.asset.com/msp/tlscacerts
    # cp ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer1.issuer.asset.com/tls/keystore/* ${PWD}/../organizations/peerOrganizations/issuer.asset.com/msp/tlscacerts/ca.crt

    # mkdir ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer1.issuer.asset.com/tlsca
    # cp ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer1.issuer.asset.com/tls/tlscacerts/* ${PWD}/../organizations/peerOrganizations/issuer.asset.com/tlsca/tlsca.issuer.asset.com-cert.pem

    # mkdir ${PWD}/../organizations/peerOrganizations/issuer.asset.com/ca
    # cp ${PWD}/../organizations/peerOrganizations/issuer.asset.com/peers/peer1.issuer.asset.com/msp/cacerts/* ${PWD}/../organizations/peerOrganizations/issuer.asset.com/ca/ca.issuer.asset.com-cert.pem
    
    # ------------------------------------------------------------------------------------------
    mkdir -p ../organizations/peerOrganizations/issuer.asset.com/users
    mkdir -p ../organizations/peerOrganizations/issuer.asset.com/users/User1@issuer.asset.com

    echo
    echo "Generate User1 MSP"
    echo
    fabric-ca-client enroll -u https://user1:user1pw@localhost:8054 --caname ca.issuer.asset.com -M ${PWD}/../organizations/peerOrganizations/issuer.asset.com/users/User1@issuer.asset.com/msp --tls.certfiles ${PWD}/../organizations/fabric-ca/issuer/tls-cert.pem

    mkdir -p ../organizations/peerOrganizations/issuer.asset.com/users/Admin@issuer.asset.com

    echo
    echo "Generate Issuer Admin MSP"
    echo

    fabric-ca-client enroll -u https://org2admin:adminpw@localhost:8054 --caname ca.issuer.asset.com -M ${PWD}/../organizations/peerOrganizations/issuer.asset.com/users/Admin@issuer.asset.com/msp --tls.certfiles ${PWD}/../organizations/fabric-ca/issuer/tls-cert.pem

    cp ${PWD}/../organizations/peerOrganizations/issuer.asset.com/msp/config.yaml ${PWD}/../organizations/peerOrganizations/issuer.asset.com/users/Admin@issuer.asset.com/msp/config.yaml
}

createCertForAgent() {
    echo
    echo "Enroll CA admin of Agent"
    echo
    mkdir -p ../organizations/peerOrganizations/agent.asset.com/
    export FABRIC_CA_CLIENT_HOME=${PWD}/../organizations/peerOrganizations/agent.asset.com/

    fabric-ca-client enroll -u https://admin:adminpw@localhost:9054 --caname ca.agent.asset.com --tls.certfiles ${PWD}/../organizations/fabric-ca/agent/tls-cert.pem

    echo 'NodeOUs:
  Enable: true
  ClientOUIdentifier:
    Certificate: cacerts/localhost-9054-ca-agent-asset-com.pem
    OrganizationalUnitIdentifier: client
  PeerOUIdentifier:
    Certificate: cacerts/localhost-9054-ca-agent-asset-com.pem
    OrganizationalUnitIdentifier: peer
  AdminOUIdentifier:
    Certificate: cacerts/localhost-9054-ca-agent-asset-com.pem
    OrganizationalUnitIdentifier: admin
  OrdererOUIdentifier:
    Certificate: cacerts/localhost-9054-ca-agent-asset-com.pem
    OrganizationalUnitIdentifier: orderer' >${PWD}/../organizations/peerOrganizations/agent.asset.com/msp/config.yaml

    echo
    echo "Register peer0.agent"
    echo

    fabric-ca-client register --caname ca.agent.asset.com --id.name peer0 --id.secret peer0pw --id.type peer --tls.certfiles ${PWD}/../organizations/fabric-ca/agent/tls-cert.pem

    echo
    echo "Register peer1.agent"
    echo

    fabric-ca-client register --caname ca.agent.asset.com --id.name peer1 --id.secret peer1pw --id.type peer --tls.certfiles ${PWD}/../organizations/fabric-ca/agent/tls-cert.pem

    echo
    echo "Register user1.agent"
    echo

    fabric-ca-client register --caname ca.agent.asset.com --id.name user1 --id.secret user1pw --id.type client --tls.certfiles ${PWD}/../organizations/fabric-ca/agent/tls-cert.pem

    echo
    echo "Register admin.agent"
    echo

    fabric-ca-client register --caname ca.agent.asset.com --id.name org3admin --id.secret adminpw --id.type admin --tls.certfiles ${PWD}/../organizations/fabric-ca/agent/tls-cert.pem

    mkdir -p ../organizations/peerOrganizations/agent.asset.com/peers
    
    # -----------------------------------------------------------------------------------
    # Peer0
    mkdir -p ../organizations/peerOrganizations/agent.asset.com/peers/peer0.agent.asset.com

    echo
    echo "Generate Peer0 MSP"
    echo

    fabric-ca-client enroll -u https://peer0:peer0pw@localhost:9054 --caname ca.agent.asset.com -M ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer0.agent.asset.com/msp --csr.hosts peer0.agent.asset.com --tls.certfiles ${PWD}/../organizations/fabric-ca/agent/tls-cert.pem

    cp ${PWD}/../organizations/peerOrganizations/agent.asset.com/msp/config.yaml ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer0.agent.asset.com/msp/config.yaml

    echo
    echo "Generate Peer0 TLS-CERTs"
    echo

    fabric-ca-client enroll -u https://peer0:peer0pw@localhost:9054 --caname ca.agent.asset.com -M ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer0.agent.asset.com/tls --enrollment.profile tls --csr.hosts peer0.agent.asset.com --csr.hosts localhost --tls.certfiles ${PWD}/../organizations/fabric-ca/agent/tls-cert.pem

    cp ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer0.agent.asset.com/tls/tlscacerts/* ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer0.agent.asset.com/tls/ca.crt
    cp ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer0.agent.asset.com/tls/signcerts/* ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer0.agent.asset.com/tls/server.crt
    cp ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer0.agent.asset.com/tls/keystore/* ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer0.agent.asset.com/tls/server.key

    mkdir ${PWD}/../organizations/peerOrganizations/agent.asset.com/msp/tlscacerts
    cp ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer0.agent.asset.com/tls/tlscacerts/* ${PWD}/../organizations/peerOrganizations/agent.asset.com/msp/tlscacerts/ca.crt

    mkdir ${PWD}/../organizations/peerOrganizations/agent.asset.com/tlsca
    cp ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer0.agent.asset.com/tls/tlscacerts/* ${PWD}/../organizations/peerOrganizations/agent.asset.com/tlsca/tlsca.agent.asset.com-cert.pem

    mkdir ${PWD}/../organizations/peerOrganizations/agent.asset.com/ca
    cp ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer0.agent.asset.com/msp/cacerts/* ${PWD}/../organizations/peerOrganizations/agent.asset.com/ca/ca.agent.asset.com-cert.pem

    # -----------------------------------------------------------------------------------
    # Peer1
    mkdir -p ../organizations/peerOrganizations/agent.asset.com/peers/peer1.agent.asset.com

    echo
    echo "Generate Peer1 MSP"
    echo

    fabric-ca-client enroll -u https://peer1:peer1pw@localhost:9054 --caname ca.agent.asset.com -M ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer1.agent.asset.com/msp --csr.hosts peer1.agent.asset.com --tls.certfiles ${PWD}/../organizations/fabric-ca/agent/tls-cert.pem

    cp ${PWD}/../organizations/peerOrganizations/agent.asset.com/msp/config.yaml ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer1.agent.asset.com/msp/config.yaml

    echo
    echo "Generate Peer1 TLS-CERTs"
    echo

    fabric-ca-client enroll -u https://peer1:peer1pw@localhost:9054 --caname ca.agent.asset.com -M ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer1.agent.asset.com/tls --enrollment.profile tls --csr.hosts peer1.agent.asset.com --csr.hosts localhost --tls.certfiles ${PWD}/../organizations/fabric-ca/agent/tls-cert.pem

    cp ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer1.agent.asset.com/tls/tlscacerts/* ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer1.agent.asset.com/tls/ca.crt
    cp ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer1.agent.asset.com/tls/signcerts/* ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer1.agent.asset.com/tls/server.crt
    cp ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer1.agent.asset.com/tls/keystore/* ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer1.agent.asset.com/tls/server.key

    # mkdir ${PWD}/../organizations/peerOrganizations/agent.asset.com/msp/tlscacerts
    # cp ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer1.agent.asset.com/tls/keystore/* ${PWD}/../organizations/peerOrganizations/agent.asset.com/msp/tlscacerts/ca.crt

    # mkdir ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer1.agent.asset.com/tlsca
    # cp ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer1.agent.asset.com/tls/tlscacerts/* ${PWD}/../organizations/peerOrganizations/agent.asset.com/tlsca/tlsca.agent.asset.com-cert.pem

    # mkdir ${PWD}/../organizations/peerOrganizations/agent.asset.com/ca
    # cp ${PWD}/../organizations/peerOrganizations/agent.asset.com/peers/peer1.agent.asset.com/msp/cacerts/* ${PWD}/../organizations/peerOrganizations/agent.asset.com/ca/ca.agent.asset.com-cert.pem

    # ------------------------------------------------------------------------------------------
    mkdir -p ../organizations/peerOrganizations/agent.asset.com/users
    mkdir -p ../organizations/peerOrganizations/agent.asset.com/users/User1@agent.asset.com

    echo
    echo "Generate User1 MSP"
    echo
    fabric-ca-client enroll -u https://user1:user1pw@localhost:9054 --caname ca.agent.asset.com -M ${PWD}/../organizations/peerOrganizations/agent.asset.com/users/User1@agent.asset.com/msp --tls.certfiles ${PWD}/../organizations/fabric-ca/agent/tls-cert.pem

    mkdir -p ../organizations/peerOrganizations/agent.asset.com/users/Admin@agent.asset.com

    echo
    echo "Generate Agent Admin MSP"
    echo

    fabric-ca-client enroll -u https://org3admin:adminpw@localhost:9054 --caname ca.agent.asset.com -M ${PWD}/../organizations/peerOrganizations/agent.asset.com/users/Admin@agent.asset.com/msp --tls.certfiles ${PWD}/../organizations/fabric-ca/agent/tls-cert.pem

    cp ${PWD}/../organizations/peerOrganizations/agent.asset.com/msp/config.yaml ${PWD}/../organizations/peerOrganizations/agent.asset.com/users/Admin@agent.asset.com/msp/config.yaml
    
}

createCertForInvestor() {
    echo
    echo "Enroll CA admin of Investor"
    echo
    mkdir -p ../organizations/peerOrganizations/investor.asset.com/
    export FABRIC_CA_CLIENT_HOME=${PWD}/../organizations/peerOrganizations/investor.asset.com/

    fabric-ca-client enroll -u https://admin:adminpw@localhost:10054 --caname ca.investor.asset.com --tls.certfiles ${PWD}/../organizations/fabric-ca/investor/tls-cert.pem

    echo 'NodeOUs:
  Enable: true
  ClientOUIdentifier:
    Certificate: cacerts/localhost-10054-ca-investor-asset-com.pem
    OrganizationalUnitIdentifier: client
  PeerOUIdentifier:
    Certificate: cacerts/localhost-10054-ca-investor-asset-com.pem
    OrganizationalUnitIdentifier: peer
  AdminOUIdentifier:
    Certificate: cacerts/localhost-10054-ca-investor-asset-com.pem
    OrganizationalUnitIdentifier: admin
  OrdererOUIdentifier:
    Certificate: cacerts/localhost-10054-ca-investor-asset-com.pem
    OrganizationalUnitIdentifier: orderer' >${PWD}/../organizations/peerOrganizations/investor.asset.com/msp/config.yaml

    echo
    echo "Register peer0.investor"
    echo

    fabric-ca-client register --caname ca.investor.asset.com --id.name peer0 --id.secret peer0pw --id.type peer --tls.certfiles ${PWD}/../organizations/fabric-ca/investor/tls-cert.pem

    echo
    echo "Register peer1.investor"
    echo

    fabric-ca-client register --caname ca.investor.asset.com --id.name peer1 --id.secret peer1pw --id.type peer --tls.certfiles ${PWD}/../organizations/fabric-ca/investor/tls-cert.pem

    echo
    echo "Register user1.investor"
    echo

    fabric-ca-client register --caname ca.investor.asset.com --id.name user1 --id.secret user1pw --id.type client --tls.certfiles ${PWD}/../organizations/fabric-ca/investor/tls-cert.pem

    echo
    echo "Register admin.investor"
    echo

    fabric-ca-client register --caname ca.investor.asset.com --id.name org4admin --id.secret adminpw --id.type admin --tls.certfiles ${PWD}/../organizations/fabric-ca/investor/tls-cert.pem

    mkdir -p ../organizations/peerOrganizations/investor.asset.com/peers
    
    # -----------------------------------------------------------------------------------
    # Peer0
    mkdir -p ../organizations/peerOrganizations/investor.asset.com/peers/peer0.investor.asset.com

    echo
    echo "Generate Peer0 MSP"
    echo

    fabric-ca-client enroll -u https://peer0:peer0pw@localhost:10054 --caname ca.investor.asset.com -M ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer0.investor.asset.com/msp --csr.hosts peer0.investor.asset.com --tls.certfiles ${PWD}/../organizations/fabric-ca/investor/tls-cert.pem

    cp ${PWD}/../organizations/peerOrganizations/investor.asset.com/msp/config.yaml ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer0.investor.asset.com/msp/config.yaml

    echo
    echo "Generate Peer0 TLS-CERTs"
    echo

    fabric-ca-client enroll -u https://peer0:peer0pw@localhost:10054 --caname ca.investor.asset.com -M ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer0.investor.asset.com/tls --enrollment.profile tls --csr.hosts peer0.investor.asset.com --csr.hosts localhost --tls.certfiles ${PWD}/../organizations/fabric-ca/investor/tls-cert.pem

    cp ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer0.investor.asset.com/tls/tlscacerts/* ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer0.investor.asset.com/tls/ca.crt
    cp ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer0.investor.asset.com/tls/signcerts/* ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer0.investor.asset.com/tls/server.crt
    cp ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer0.investor.asset.com/tls/keystore/* ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer0.investor.asset.com/tls/server.key

    mkdir ${PWD}/../organizations/peerOrganizations/investor.asset.com/msp/tlscacerts
    cp ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer0.investor.asset.com/tls/tlscacerts/* ${PWD}/../organizations/peerOrganizations/investor.asset.com/msp/tlscacerts/ca.crt

    mkdir ${PWD}/../organizations/peerOrganizations/investor.asset.com/tlsca
    cp ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer0.investor.asset.com/tls/tlscacerts/* ${PWD}/../organizations/peerOrganizations/investor.asset.com/tlsca/tlsca.investor.asset.com-cert.pem

    mkdir ${PWD}/../organizations/peerOrganizations/investor.asset.com/ca
    cp ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer0.investor.asset.com/msp/cacerts/* ${PWD}/../organizations/peerOrganizations/investor.asset.com/ca/ca.investor.asset.com-cert.pem

    # -----------------------------------------------------------------------------------
    # Peer1
    mkdir -p ../organizations/peerOrganizations/investor.asset.com/peers/peer1.investor.asset.com

    echo
    echo "Generate Peer1 MSP"
    echo

    fabric-ca-client enroll -u https://peer1:peer1pw@localhost:10054 --caname ca.investor.asset.com -M ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer1.investor.asset.com/msp --csr.hosts peer1.investor.asset.com --tls.certfiles ${PWD}/../organizations/fabric-ca/investor/tls-cert.pem

    cp ${PWD}/../organizations/peerOrganizations/investor.asset.com/msp/config.yaml ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer1.investor.asset.com/msp/config.yaml

    echo
    echo "Generate Peer1 TLS-CERTs"
    echo

    fabric-ca-client enroll -u https://peer1:peer1pw@localhost:10054 --caname ca.investor.asset.com -M ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer1.investor.asset.com/tls --enrollment.profile tls --csr.hosts peer1.investor.asset.com --csr.hosts localhost --tls.certfiles ${PWD}/../organizations/fabric-ca/investor/tls-cert.pem

    cp ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer1.investor.asset.com/tls/tlscacerts/* ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer1.investor.asset.com/tls/ca.crt
    cp ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer1.investor.asset.com/tls/signcerts/* ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer1.investor.asset.com/tls/server.crt
    cp ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer1.investor.asset.com/tls/keystore/* ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer1.investor.asset.com/tls/server.key

    # mkdir ${PWD}/../organizations/peerOrganizations/investor.asset.com/msp/tlscacerts
    # cp ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer1.investor.asset.com/tls/keystore/* ${PWD}/../organizations/peerOrganizations/investor.asset.com/msp/tlscacerts/ca.crt

    # mkdir ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer1.investor.asset.com/tlsca
    # cp ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer1.investor.asset.com/tls/tlscacerts/* ${PWD}/../organizations/peerOrganizations/investor.asset.com/tlsca/tlsca.investor.asset.com-cert.pem

    # mkdir ${PWD}/../organizations/peerOrganizations/investor.asset.com/ca
    # cp ${PWD}/../organizations/peerOrganizations/investor.asset.com/peers/peer1.investor.asset.com/msp/cacerts/* ${PWD}/../organizations/peerOrganizations/investor.asset.com/ca/ca.investor.asset.com-cert.pem

    # ------------------------------------------------------------------------------------------
    mkdir -p ../organizations/peerOrganizations/investor.asset.com/users
    mkdir -p ../organizations/peerOrganizations/investor.asset.com/users/User1@investor.asset.com

    echo
    echo "Generate User1 MSP"
    echo
    fabric-ca-client enroll -u https://user1:user1pw@localhost:10054 --caname ca.investor.asset.com -M ${PWD}/../organizations/peerOrganizations/investor.asset.com/users/User1@investor.asset.com/msp --tls.certfiles ${PWD}/../organizations/fabric-ca/investor/tls-cert.pem

    mkdir -p ../organizations/peerOrganizations/investor.asset.com/users/Admin@investor.asset.com

    echo
    echo "Generate Investor Admin MSP"
    echo

    fabric-ca-client enroll -u https://org4admin:adminpw@localhost:10054 --caname ca.investor.asset.com -M ${PWD}/../organizations/peerOrganizations/investor.asset.com/users/Admin@investor.asset.com/msp --tls.certfiles ${PWD}/../organizations/fabric-ca/investor/tls-cert.pem

    cp ${PWD}/../organizations/peerOrganizations/investor.asset.com/msp/config.yaml ${PWD}/../organizations/peerOrganizations/investor.asset.com/users/Admin@investor.asset.com/msp/config.yaml
    
}

createCretificateForOrderer() {
  echo
  echo "Enroll CA admin of Orderer"
  echo
  mkdir -p ../organizations/ordererOrganizations/asset.com

  export FABRIC_CA_CLIENT_HOME=${PWD}/../organizations/ordererOrganizations/asset.com

  fabric-ca-client enroll -u https://admin:adminpw@localhost:11054 --caname ca-orderer --tls.certfiles ${PWD}/../organizations/fabric-ca/ordererOrg/tls-cert.pem

  echo 'NodeOUs:
  Enable: true
  ClientOUIdentifier:
    Certificate: cacerts/localhost-11054-ca-orderer.pem
    OrganizationalUnitIdentifier: client
  PeerOUIdentifier:
    Certificate: cacerts/localhost-11054-ca-orderer.pem
    OrganizationalUnitIdentifier: peer
  AdminOUIdentifier:
    Certificate: cacerts/localhost-11054-ca-orderer.pem
    OrganizationalUnitIdentifier: admin
  OrdererOUIdentifier:
    Certificate: cacerts/localhost-11054-ca-orderer.pem
    OrganizationalUnitIdentifier: orderer' >${PWD}/../organizations/ordererOrganizations/asset.com/msp/config.yaml

  echo
  echo "Register orderer"
  echo

  fabric-ca-client register --caname ca-orderer --id.name orderer --id.secret ordererpw --id.type orderer --tls.certfiles ${PWD}/../organizations/fabric-ca/ordererOrg/tls-cert.pem

  echo
  echo "Register orderer2"
  echo

  fabric-ca-client register --caname ca-orderer --id.name orderer2 --id.secret ordererpw --id.type orderer --tls.certfiles ${PWD}/../organizations/fabric-ca/ordererOrg/tls-cert.pem

  echo
  echo "Register orderer3"
  echo

  fabric-ca-client register --caname ca-orderer --id.name orderer3 --id.secret ordererpw --id.type orderer --tls.certfiles ${PWD}/../organizations/fabric-ca/ordererOrg/tls-cert.pem

  echo
  echo "Register orderer4"
  echo

  fabric-ca-client register --caname ca-orderer --id.name orderer4 --id.secret ordererpw --id.type orderer --tls.certfiles ${PWD}/../organizations/fabric-ca/ordererOrg/tls-cert.pem

  echo
  echo "Register orderer5"
  echo

  fabric-ca-client register --caname ca-orderer --id.name orderer5 --id.secret ordererpw --id.type orderer --tls.certfiles ${PWD}/../organizations/fabric-ca/ordererOrg/tls-cert.pem


  echo
  echo "Register the Orderer Admin"
  echo

  fabric-ca-client register --caname ca-orderer --id.name ordererAdmin --id.secret ordererAdminpw --id.type admin --tls.certfiles ${PWD}/../organizations/fabric-ca/ordererOrg/tls-cert.pem

  mkdir -p ../organizations/ordererOrganizations/asset.com/orderers
  # mkdir -p ../organizations/ordererOrganizations/asset.com/orderers/asset.com

  # ---------------------------------------------------------------------------
  #  Orderer

  mkdir -p ../organizations/ordererOrganizations/asset.com/orderers/orderer.asset.com

  echo
  echo "Generate the Orderer MSP"
  echo

  fabric-ca-client enroll -u https://orderer:ordererpw@localhost:11054 --caname ca-orderer -M ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer.asset.com/msp --csr.hosts orderer.asset.com --csr.hosts localhost --tls.certfiles ${PWD}/../organizations/fabric-ca/ordererOrg/tls-cert.pem

  cp ${PWD}/../organizations/ordererOrganizations/asset.com/msp/config.yaml ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer.asset.com/msp/config.yaml

  echo
  echo "Generate the orderer TLS Certs"
  echo

  fabric-ca-client enroll -u https://orderer:ordererpw@localhost:11054 --caname ca-orderer -M ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer.asset.com/tls --enrollment.profile tls --csr.hosts orderer.asset.com --csr.hosts localhost --tls.certfiles ${PWD}/../organizations/fabric-ca/ordererOrg/tls-cert.pem

  cp ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer.asset.com/tls/tlscacerts/* ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer.asset.com/tls/ca.crt
  cp ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer.asset.com/tls/signcerts/* ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer.asset.com/tls/server.crt
  cp ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer.asset.com/tls/keystore/* ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer.asset.com/tls/server.key

  mkdir ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer.asset.com/msp/tlscacerts
  cp ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer.asset.com/tls/tlscacerts/* ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer.asset.com/msp/tlscacerts/tlsca.asset.com-cert.pem

  mkdir ${PWD}/../organizations/ordererOrganizations/asset.com/msp/tlscacerts
  cp ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer.asset.com/tls/tlscacerts/* ${PWD}/../organizations/ordererOrganizations/asset.com/msp/tlscacerts/tlsca.asset.com-cert.pem

  # -----------------------------------------------------------------------
  #  Orderer 2

  mkdir -p ../organizations/ordererOrganizations/asset.com/orderers/orderer2.asset.com

  echo
  echo "Generate the Orderer2 MSP"
  echo

  fabric-ca-client enroll -u https://orderer2:ordererpw@localhost:11054 --caname ca-orderer -M ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer2.asset.com/msp --csr.hosts orderer2.asset.com --csr.hosts localhost --tls.certfiles ${PWD}/../organizations/fabric-ca/ordererOrg/tls-cert.pem

  cp ${PWD}/../organizations/ordererOrganizations/asset.com/msp/config.yaml ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer2.asset.com/msp/config.yaml

  echo
  echo "Generate the Orderer2 TLS Certs"
  echo

  fabric-ca-client enroll -u https://orderer2:ordererpw@localhost:11054 --caname ca-orderer -M ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer2.asset.com/tls --enrollment.profile tls --csr.hosts orderer2.asset.com --csr.hosts localhost --tls.certfiles ${PWD}/../organizations/fabric-ca/ordererOrg/tls-cert.pem

  cp ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer2.asset.com/tls/tlscacerts/* ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer2.asset.com/tls/ca.crt
  cp ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer2.asset.com/tls/signcerts/* ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer2.asset.com/tls/server.crt
  cp ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer2.asset.com/tls/keystore/* ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer2.asset.com/tls/server.key

  mkdir ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer2.asset.com/msp/tlscacerts
  cp ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer2.asset.com/tls/tlscacerts/* ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer2.asset.com/msp/tlscacerts/tlsca.asset.com-cert.pem

  # ---------------------------------------------------------------------------
  #  Orderer 3
  mkdir -p ../organizations/ordererOrganizations/asset.com/orderers/orderer3.asset.com

  echo
  echo "Generate the Orderer3 MSP"
  echo

  fabric-ca-client enroll -u https://orderer3:ordererpw@localhost:11054 --caname ca-orderer -M ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer3.asset.com/msp --csr.hosts orderer3.asset.com --csr.hosts localhost --tls.certfiles ${PWD}/../organizations/fabric-ca/ordererOrg/tls-cert.pem

  cp ${PWD}/../organizations/ordererOrganizations/asset.com/msp/config.yaml ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer3.asset.com/msp/config.yaml

  echo
  echo "Generate the Orderer3 TLS certs"
  echo

  fabric-ca-client enroll -u https://orderer3:ordererpw@localhost:11054 --caname ca-orderer -M ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer3.asset.com/tls --enrollment.profile tls --csr.hosts orderer3.asset.com --csr.hosts localhost --tls.certfiles ${PWD}/../organizations/fabric-ca/ordererOrg/tls-cert.pem

  cp ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer3.asset.com/tls/tlscacerts/* ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer3.asset.com/tls/ca.crt
  cp ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer3.asset.com/tls/signcerts/* ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer3.asset.com/tls/server.crt
  cp ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer3.asset.com/tls/keystore/* ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer3.asset.com/tls/server.key

  mkdir ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer3.asset.com/msp/tlscacerts
  cp ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer3.asset.com/tls/tlscacerts/* ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer3.asset.com/msp/tlscacerts/tlsca.asset.com-cert.pem
  # ---------------------------------------------------------------------------

  #  Orderer 4
  mkdir -p ../organizations/ordererOrganizations/asset.com/orderers/orderer4.asset.com

  echo
  echo "Generate the orderer4 MSP"
  echo

  fabric-ca-client enroll -u https://orderer4:ordererpw@localhost:11054 --caname ca-orderer -M ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer4.asset.com/msp --csr.hosts orderer4.asset.com --csr.hosts localhost --tls.certfiles ${PWD}/../organizations/fabric-ca/ordererOrg/tls-cert.pem

  cp ${PWD}/../organizations/ordererOrganizations/asset.com/msp/config.yaml ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer4.asset.com/msp/config.yaml

  echo
  echo "Generate the orderer4 TLS certs"
  echo

  fabric-ca-client enroll -u https://orderer4:ordererpw@localhost:11054 --caname ca-orderer -M ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer4.asset.com/tls --enrollment.profile tls --csr.hosts orderer4.asset.com --csr.hosts localhost --tls.certfiles ${PWD}/../organizations/fabric-ca/ordererOrg/tls-cert.pem

  cp ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer4.asset.com/tls/tlscacerts/* ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer4.asset.com/tls/ca.crt
  cp ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer4.asset.com/tls/signcerts/* ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer4.asset.com/tls/server.crt
  cp ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer4.asset.com/tls/keystore/* ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer4.asset.com/tls/server.key

  mkdir ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer4.asset.com/msp/tlscacerts
  cp ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer4.asset.com/tls/tlscacerts/* ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer4.asset.com/msp/tlscacerts/tlsca.asset.com-cert.pem
  # ---------------------------------------------------------------------------

  #  Orderer 5
  mkdir -p ../organizations/ordererOrganizations/asset.com/orderers/orderer5.asset.com

  echo
  echo "Generate the orderer5 MSP"
  echo

  fabric-ca-client enroll -u https://orderer5:ordererpw@localhost:11054 --caname ca-orderer -M ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer5.asset.com/msp --csr.hosts orderer5.asset.com --csr.hosts localhost --tls.certfiles ${PWD}/../organizations/fabric-ca/ordererOrg/tls-cert.pem

  cp ${PWD}/../organizations/ordererOrganizations/asset.com/msp/config.yaml ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer5.asset.com/msp/config.yaml

  echo
  echo "Generate the orderer5 TLS certs"
  echo

  fabric-ca-client enroll -u https://orderer5:ordererpw@localhost:11054 --caname ca-orderer -M ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer5.asset.com/tls --enrollment.profile tls --csr.hosts orderer5.asset.com --csr.hosts localhost --tls.certfiles ${PWD}/../organizations/fabric-ca/ordererOrg/tls-cert.pem

  cp ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer5.asset.com/tls/tlscacerts/* ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer5.asset.com/tls/ca.crt
  cp ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer5.asset.com/tls/signcerts/* ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer5.asset.com/tls/server.crt
  cp ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer5.asset.com/tls/keystore/* ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer5.asset.com/tls/server.key

  mkdir ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer5.asset.com/msp/tlscacerts
  cp ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer5.asset.com/tls/tlscacerts/* ${PWD}/../organizations/ordererOrganizations/asset.com/orderers/orderer5.asset.com/msp/tlscacerts/tlsca.asset.com-cert.pem
  # ---------------------------------------------------------------------------  
  
  mkdir -p ../organizations/ordererOrganizations/asset.com/users
  mkdir -p ../organizations/ordererOrganizations/asset.com/users/Admin@asset.com

  echo
  echo "Generate the Admin MSP Orderer"
  echo

  fabric-ca-client enroll -u https://ordererAdmin:ordererAdminpw@localhost:11054 --caname ca-orderer -M ${PWD}/../organizations/ordererOrganizations/asset.com/users/Admin@asset.com/msp --tls.certfiles ${PWD}/../organizations/fabric-ca/ordererOrg/tls-cert.pem

  cp ${PWD}/../organizations/ordererOrganizations/asset.com/msp/config.yaml ${PWD}/../organizations/ordererOrganizations/asset.com/users/Admin@asset.com/msp/config.yaml

}

createCertForSysAdmin
createCertForIssuer
createCertForAgent
createCertForInvestor
createCretificateForOrderer