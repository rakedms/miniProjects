#!/bin/bash 
source ../terminal_control.sh
export PATH=/home/rakeshdms/fabric-components/binV2.2/fabric-samples/bin:$PATH
export FABRIC_CFG_PATH=${PWD}/configtx/
print Blue "$FABRIC_CFG_PATH"

# # Generate crypto material using cryptogen tool
# print Green "========== Generating Crypto Material =========="
# echo ""

# ../../fabric-samples/bin/cryptogen generate --config=./crypto-config.yaml --output="organizations"

# print Green "========== Crypto Material Generated =========="
# echo ""

SYS_CHANNEL=asset-sys-channel
print Purple "System Channel Name: "$SYS_CHANNEL
echo ""

CHANNEL_NAME=asset-channel
print Purple "Application Channel Name: "$CHANNEL_NAME
echo ""

# Generate System Genesis Block using configtxgen tool
print Green "========== Generating System Genesis Block =========="
echo ""

configtxgen -configPath ./configtx/ -profile AssetOrdererGenesis -channelID $SYS_CHANNEL -outputBlock ./channel-artifacts/genesis.block

print Green "========== System Genesis Block Generated =========="
echo ""

print Green "========== Generating Channel Configuration Block =========="
echo ""

configtxgen -profile AssetChannel -configPath ./configtx/ -outputCreateChannelTx ./channel-artifacts/asset-channel.tx -channelID $CHANNEL_NAME 

print Green "========== Channel Configuration Block Generated =========="
echo ""

print Green "========== Generating Anchor Peer Update For SysAdminMSP =========="
echo ""

configtxgen -profile AssetChannel -configPath ./configtx/ -outputAnchorPeersUpdate ./channel-artifacts/SysAdminMSPAnchor.tx -channelID $CHANNEL_NAME -asOrg SysAdminMSP

print Green "========== Anchor Peer Update For SysAdminMSP Sucessful =========="
echo ""

print Green "========== Generating Anchor Peer Update For IssuerMSP =========="
echo ""

configtxgen -profile AssetChannel -configPath ./configtx/ -outputAnchorPeersUpdate ./channel-artifacts/IssuerMSPAnchor.tx -channelID $CHANNEL_NAME -asOrg IssuerMSP

print Green "========== Anchor Peer Update For IssuerMSP Sucessful =========="
echo ""

print Green "========== Generating Anchor Peer Update For AgentMSP =========="
echo ""

configtxgen -profile AssetChannel -configPath ./configtx/ -outputAnchorPeersUpdate ./channel-artifacts/AgentMSPAnchor.tx -channelID $CHANNEL_NAME -asOrg AgentMSP

print Green "========== Anchor Peer Update For AgentMSP Sucessful =========="
echo ""

print Green "========== Generating Anchor Peer Update For InvestorMSP =========="
echo ""

configtxgen -profile AssetChannel -configPath ./configtx/ -outputAnchorPeersUpdate ./channel-artifacts/InvestorMSPAnchor.tx -channelID $CHANNEL_NAME -asOrg InvestorMSP

print Green "========== Anchor Peer Update For InvestorMSP Sucessful =========="
echo ""

