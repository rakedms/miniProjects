#!/bin/bash
source ../terminal_control.sh
export PATH=/home/rakeshdms/fabric-components/binV2.2/fabric-samples/bin:$PATH
export PATH=/usr/local/go/bin:$PATH 
export FABRIC_CFG_PATH=${PWD}/../config
export ORDERER_CA=${PWD}/organizations/ordererOrganizations/asset.com/orderers/orderer.asset.com/msp/tlscacerts/tlsca.asset.com-cert.pem
export CORE_PEER_TLS_ROOTCERT_FILE_ORG1=${PWD}/organizations/peerOrganizations/sysadmin.asset.com/peers/peer0.sysadmin.asset.com/tls/ca.crt
export CORE_PEER_TLS_ROOTCERT_FILE_ORG2=${PWD}/organizations/peerOrganizations/issuer.asset.com/peers/peer0.issuer.asset.com/tls/ca.crt
export CORE_PEER_TLS_ROOTCERT_FILE_ORG3=${PWD}/organizations/peerOrganizations/agent.asset.com/peers/peer0.agent.asset.com/tls/ca.crt
export CORE_PEER_TLS_ROOTCERT_FILE_ORG4=${PWD}/organizations/peerOrganizations/investor.asset.com/peers/peer0.investor.asset.com/tls/ca.crt


CHANNEL_NAME="asset-channel"
CHAINCODE_NAME="assetcode"
CHAINCODE_VERSION="1.0"
CHAINCODE_PATH="../chaincode/assetcode/go/"
CHAINCODE_LABEL="assetcode_1"

setEnvForSysAdmin() {
    export CORE_PEER_TLS_ENABLED=true
    export CORE_PEER_LOCALMSPID=SysAdminMSP
    export CORE_PEER_TLS_ROOTCERT_FILE=${PWD}/organizations/peerOrganizations/sysadmin.asset.com/peers/peer0.sysadmin.asset.com/tls/ca.crt
    export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/sysadmin.asset.com/users/Admin@sysadmin.asset.com/msp
    export CORE_PEER_ADDRESS=localhost:7051
}

setEnvForIssuer() {
    export CORE_PEER_TLS_ENABLED=true
    export CORE_PEER_LOCALMSPID=IssuerMSP
    export CORE_PEER_TLS_ROOTCERT_FILE=${PWD}/organizations/peerOrganizations/issuer.asset.com/peers/peer0.issuer.asset.com/tls/ca.crt
    export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/issuer.asset.com/users/Admin@issuer.asset.com/msp
    export CORE_PEER_ADDRESS=localhost:9051
}

setEnvForAgent() {
    export CORE_PEER_TLS_ENABLED=true
    export CORE_PEER_LOCALMSPID=AgentMSP
    export CORE_PEER_TLS_ROOTCERT_FILE=${PWD}/organizations/peerOrganizations/agent.asset.com/peers/peer0.agent.asset.com/tls/ca.crt
    export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/agent.asset.com/users/Admin@agent.asset.com/msp
    export CORE_PEER_ADDRESS=localhost:11051
}

setEnvForInvestor() {
    export CORE_PEER_TLS_ENABLED=true
    export CORE_PEER_LOCALMSPID=InvestorMSP
    export CORE_PEER_TLS_ROOTCERT_FILE=${PWD}/organizations/peerOrganizations/investor.asset.com/peers/peer0.investor.asset.com/tls/ca.crt
    export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/investor.asset.com/users/Admin@investor.asset.com/msp
    export CORE_PEER_ADDRESS=localhost:13051
}

packageChaincode() {
    rm -rf ${CHAINCODE_NAME}.tar.gz
    setEnvForSysAdmin
    print Green "========== Packaging Chaincode on Peer0 SysAdmin =========="
    peer lifecycle chaincode package ${CHAINCODE_NAME}.tar.gz --path ${CHAINCODE_PATH} --lang golang --label ${CHAINCODE_LABEL}
    echo ""
    print Green "========== Packaging Chaincode on Peer0 SysAdmin Successful =========="
    ls
    echo ""
}

installChaincode() {
    setEnvForSysAdmin
    print Green "========== Installing Chaincode on Peer0 SysAdmin =========="
    peer lifecycle chaincode install ${CHAINCODE_NAME}.tar.gz --peerAddresses localhost:7051 --tlsRootCertFiles ${CORE_PEER_TLS_ROOTCERT_FILE}
    print Green "========== Installed Chaincode on Peer0 SysAdmin =========="
    echo ""

    setEnvForIssuer
    print Green "========== Installing Chaincode on Peer0 sysadmin =========="
    peer lifecycle chaincode install ${CHAINCODE_NAME}.tar.gz --peerAddresses localhost:9051 --tlsRootCertFiles ${CORE_PEER_TLS_ROOTCERT_FILE}
    print Green "========== Installed Chaincode on peer0 sysadmin =========="
    echo ""

    setEnvForAgent
    print Green "========== Installing Chaincode on Peer0 agent =========="
    peer lifecycle chaincode install ${CHAINCODE_NAME}.tar.gz --peerAddresses localhost:11051 --tlsRootCertFiles ${CORE_PEER_TLS_ROOTCERT_FILE}
    print Green "========== Installed Chaincode on Peer0 agent =========="
    echo ""

    setEnvForInvestor
    print Green "========== Installing Chaincode on Peer0 agent =========="
    peer lifecycle chaincode install ${CHAINCODE_NAME}.tar.gz --peerAddresses localhost:13051 --tlsRootCertFiles ${CORE_PEER_TLS_ROOTCERT_FILE}
    print Green "========== Installed Chaincode on Peer0 agent =========="
    echo ""
}

queryInstalledChaincode() {
    setEnvForSysAdmin
    print Green "========== Querying Installed Chaincode on Peer0 SysAdmin=========="
    peer lifecycle chaincode queryinstalled --peerAddresses localhost:7051 --tlsRootCertFiles ${CORE_PEER_TLS_ROOTCERT_FILE} >&log.txt
    cat log.txt
    PACKAGE_ID=$(sed -n "/${CHAINCODE_LABEL}/{s/^Package ID: //; s/, Label:.*$//; p;}" log.txt)
    print Yellow "PackageID is ${PACKAGE_ID}"
    print Green "========== Query Installed Chaincode Successful on Peer0 SysAdmin=========="
    echo ""
}

approveChaincodeBySysAdmin() {
    setEnvForSysAdmin
    print Green "========== Approve Installed Chaincode by Peer0 SysAdmin =========="
    peer lifecycle chaincode approveformyorg -o localhost:7050 --ordererTLSHostnameOverride orderer.asset.com --tls --cafile ${ORDERER_CA} --channelID asset-channel --name ${CHAINCODE_NAME} --version ${CHAINCODE_VERSION} --package-id ${PACKAGE_ID} --sequence 1 --init-required
    print Green "========== Approve Installed Chaincode Successful by Peer0 SysAdmin =========="
    echo ""
}

checkCommitReadynessForSysAdmin() {
    setEnvForSysAdmin
    print Green "========== Check Commit Readiness of Installed Chaincode on Peer0 SysAdmin =========="
    peer lifecycle chaincode checkcommitreadiness -o localhost:7050 --channelID ${CHANNEL_NAME} --tls --cafile ${ORDERER_CA} --name ${CHAINCODE_NAME} --version ${CHAINCODE_VERSION} --sequence 1 --output json --init-required
    print Green "========== Check Commit Readiness of Installed Chaincode Successful on Peer0 SysAdmin =========="
    echo ""
}

approveChaincodeByIssuer() {
    setEnvForIssuer
    print Green "========== Approve Installed Chaincode by Peer0 sysadmin =========="
    peer lifecycle chaincode approveformyorg -o localhost:7050 --ordererTLSHostnameOverride orderer.asset.com --tls --cafile ${ORDERER_CA} --channelID asset-channel --name ${CHAINCODE_NAME} --version ${CHAINCODE_VERSION} --package-id ${PACKAGE_ID} --sequence 1 --init-required
    print Green "========== Approve Installed Chaincode Successful by Peer0 sysadmin =========="
    echo ""
}

checkCommitReadynessForIssuer() {
    setEnvForIssuer
    print Green "========== Check Commit Readiness of Installed Chaincode on Peer0 sysadmin =========="
    peer lifecycle chaincode checkcommitreadiness -o localhost:7050 --channelID ${CHANNEL_NAME} --tls --cafile ${ORDERER_CA} --name ${CHAINCODE_NAME} --version ${CHAINCODE_VERSION} --sequence 1 --output json --init-required
    print Green "========== Check Commit Readiness of Installed Chaincode Successful on Peer0 sysadmin =========="
    echo ""
}

approveChaincodeByAgent() {
    setEnvForAgent
    print Green "========== Approve Installed Chaincode by Peer0 agent =========="
    peer lifecycle chaincode approveformyorg -o localhost:7050 --ordererTLSHostnameOverride orderer.asset.com --tls --cafile ${ORDERER_CA} --channelID asset-channel --name ${CHAINCODE_NAME} --version ${CHAINCODE_VERSION} --package-id ${PACKAGE_ID} --sequence 1 --init-required
    print Green "========== Approve Installed Chaincode Successful by Peer0 agent =========="
    echo ""
}

checkCommitReadynessForAgent() {
    setEnvForAgent
    print Green "========== Check Commit Readiness of Installed Chaincode on Peer0 agent =========="
    peer lifecycle chaincode checkcommitreadiness -o localhost:7050 --channelID ${CHANNEL_NAME} --tls --cafile ${ORDERER_CA} --name ${CHAINCODE_NAME} --version ${CHAINCODE_VERSION} --sequence 1 --output json --init-required
    print Green "========== Check Commit Readiness of Installed Chaincode Successful on Peer0 agent =========="
    echo ""
}


approveChaincodeByInvestor() {
    setEnvForInvestor
    print Green "========== Approve Installed Chaincode by Peer0 investor =========="
    peer lifecycle chaincode approveformyorg -o localhost:7050 --ordererTLSHostnameOverride orderer.asset.com --tls --cafile ${ORDERER_CA} --channelID asset-channel --name ${CHAINCODE_NAME} --version ${CHAINCODE_VERSION} --package-id ${PACKAGE_ID} --sequence 1 --init-required
    print Green "========== Approve Installed Chaincode Successful by Peer0 investor =========="
    echo ""
}

checkCommitReadynessForInvestor() {
    setEnvForInvestor
    print Green "========== Check Commit Readiness of Installed Chaincode on Peer0 investor =========="
    peer lifecycle chaincode checkcommitreadiness -o localhost:7050 --channelID ${CHANNEL_NAME} --tls --cafile ${ORDERER_CA} --name ${CHAINCODE_NAME} --version ${CHAINCODE_VERSION} --sequence 1 --output json --init-required
    print Green "========== Check Commit Readiness of Installed Chaincode Successful on Peer0 investor =========="
    echo ""
}



commitChaincode() {
    setEnvForSysAdmin
    print Green "========== Commit Installed Chaincode on ${CHANNEL_NAME} =========="
    peer lifecycle chaincode commit -o localhost:7050 --ordererTLSHostnameOverride orderer.asset.com --tls ${CORE_PEER_TLS_ENABLED} --cafile ${ORDERER_CA} --channelID ${CHANNEL_NAME} --name ${CHAINCODE_NAME} \
        --peerAddresses localhost:7051 --tlsRootCertFiles ${CORE_PEER_TLS_ROOTCERT_FILE_ORG1} \
        --peerAddresses localhost:9051 --tlsRootCertFiles ${CORE_PEER_TLS_ROOTCERT_FILE_ORG2} \
        --peerAddresses localhost:11051 --tlsRootCertFiles ${CORE_PEER_TLS_ROOTCERT_FILE_ORG3} \
        --peerAddresses localhost:13051 --tlsRootCertFiles ${CORE_PEER_TLS_ROOTCERT_FILE_ORG4} \
        --version ${CHAINCODE_VERSION} --sequence 1 --init-required
    print Green "========== Commit Installed Chaincode on ${CHANNEL_NAME} Successful =========="
    echo ""
}

queryCommittedChaincode() {
    setEnvForSysAdmin
    print Green "========== Query Committed Chaincode on ${CHANNEL_NAME} =========="
    peer lifecycle chaincode querycommitted --channelID ${CHANNEL_NAME} --name ${CHAINCODE_NAME}
    print Green "========== Query Committed Chaincode on ${CHANNEL_NAME} Successful =========="
    echo ""
}

getInstalledChaincode() {
    setEnvForSysAdmin
    print Green "========== Get Installed Chaincode from Peer0 SysAdmin =========="
    peer lifecycle chaincode getinstalledpackage --package-id ${PACKAGE_ID} --output-directory . --peerAddresses localhost:7051 --tlsRootCertFiles ${CORE_PEER_TLS_ROOTCERT_FILE}
    print Green "========== Get Installed Chaincode from Peer0 SysAdmin Successful =========="
    echo ""
}

queryApprovedChaincode() {
    setEnvForSysAdmin
    print Green "========== Query Approved of Installed Chaincode on Peer0 SysAdmin =========="
    peer lifecycle chaincode queryapproved -C s${CHANNEL_NAME} -n ${CHAINCODE_NAME} --sequence 1 
    print Green "========== Query Approved of Installed Chaincode on Peer0 SysAdmin Successful =========="
    echo ""
}

initChaincode() {
    setEnvForSysAdmin
    print Green "========== Init Chaincode on Peer0 SysAdmin ========== "
    peer chaincode invoke -o localhost:7050 --ordererTLSHostnameOverride orderer.asset.com --tls ${CORE_PEER_TLS_ENABLED} --cafile ${ORDERER_CA} -C ${CHANNEL_NAME} -n ${CHAINCODE_NAME} \
        --peerAddresses localhost:7051 --tlsRootCertFiles ${CORE_PEER_TLS_ROOTCERT_FILE_ORG1} \
        --peerAddresses localhost:9051 --tlsRootCertFiles ${CORE_PEER_TLS_ROOTCERT_FILE_ORG2} \
        --peerAddresses localhost:11051 --tlsRootCertFiles ${CORE_PEER_TLS_ROOTCERT_FILE_ORG3} \
        --peerAddresses localhost:13051 --tlsRootCertFiles ${CORE_PEER_TLS_ROOTCERT_FILE_ORG4} \
        --isInit -c '{"Args":[]}'
    print Green "========== Init Chaincode on Peer0 SysAdmin Successful ========== "
    echo ""
}

if [[ $1 == "packageChaincode" ]]
then
packageChaincode
elif [[ $1 == "installChaincode" ]]
then
installChaincode
elif [[ $1 == "queryInstalledChaincode" ]]
then
queryInstalledChaincode
elif [[ $1 == "approveChaincodeBySysAdmin" ]]
then
approveChaincodeBySysAdmin
elif [[ $1 == "checkCommitReadynessForSysAdmin" ]]
then
checkCommitReadynessForSysAdmin
elif [[ $1 == "approveChaincodeByIssuer" ]]
then
approveChaincodeByIssuer
elif [[ $1 == "checkCommitReadynessForIssuer" ]]
then
checkCommitReadynessForIssuer
elif [[ $1 == "approveChaincodeByAgent" ]]
then
approveChaincodeByAgent
elif [[ $1 == "checkCommitReadynessForAgent" ]]
then
checkCommitReadynessForAgent
elif [[ $1 == "commitChaincode" ]]
then
approveChaincodeByInvestor
elif [[ $1 == "checkCommitReadynessForInvestor" ]]
then
checkCommitReadynessForInvestor
elif [[ $1 == "commitChaincode" ]]
then
commitChaincode
elif [[ $1 == "queryCommittedChaincode" ]]
then
queryCommittedChaincode
elif [[ $1 == "getInstalledChaincode" ]]
then
getInstalledChaincode
elif [[ $1 == "queryApprovedChaincode" ]]
then
queryApprovedChaincode
elif [[ $1 == "initChaincode" ]]
then
initChaincode
elif [[ $1 == "help" ]]
then
echo "Usage:" 
echo "       source chaincode_lifecycle.sh [option]"
echo "Options Available:"
echo "Follow this options in sequence"
echo "[ packageChaincode | installChaincode | queryInstalledChaincode | approveChaincodeBySysAdmin ]"
echo "[ checkCommitReadynessForSysAdmin | approveChaincodeByIssuer | checkCommitReadynessForIssuer ]"
echo "[ approveChaincodeByAgent | checkCommitReadynessForAgent | approveChaincodeByInvestor ]"
echo "[ checkCommitReadynessForInvestor | commitChaincode | queryCommittedChaincode | initChaincode ]"
echo "Other Options:"
echo "[ default(run all options in sequence at once) | getInstalledChaincode | queryApprovedChaincode | help ]"
elif [[ $1 == "default" ]]
then
packageChaincode
installChaincode
queryInstalledChaincode
approveChaincodeBySysAdmin
checkCommitReadynessForSysAdmin
approveChaincodeByIssuer
checkCommitReadynessForIssuer
approveChaincodeByAgent
checkCommitReadynessForAgent
approveChaincodeByInvestor
checkCommitReadynessForInvestor
commitChaincode
queryCommittedChaincode
initChaincode
else
print Red "$1: Invalid option. (try: source chaincode_lifecycle.sh help)"
fi

