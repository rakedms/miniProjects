#!/bin/bash
source ../terminal_control.sh
export PATH=/home/rakeshdms/fabric-components/binV2.2/fabric-samples/bin:$PATH
export FABRIC_CFG_PATH=${PWD}/../config/
export CORE_PEER_TLS_ENABLED=true
export ORDERER_CA=${PWD}/organizations/ordererOrganizations/asset.com/orderers/orderer.asset.com/msp/tlscacerts/tlsca.asset.com-cert.pem

export CHANNEL_NAME=asset-channel

setEnvForPeer0SysAdmin() {
    export PEER0_ORG1_CA=${PWD}/organizations/peerOrganizations/sysadmin.asset.com/peers/peer0.sysadmin.asset.com/tls/ca.crt
    export CORE_PEER_LOCALMSPID=SysAdminMSP
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG1_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/sysadmin.asset.com/users/Admin@sysadmin.asset.com/msp
    export CORE_PEER_ADDRESS=localhost:7051
}

setEnvForPeer1SysAdmin() {
    export PEER1_ORG1_CA=${PWD}/organizations/peerOrganizations/sysadmin.asset.com/peers/peer1.sysadmin.asset.com/tls/ca.crt
    export CORE_PEER_LOCALMSPID=SysAdminMSP
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER1_ORG1_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/sysadmin.asset.com/users/Admin@sysadmin.asset.com/msp
    export CORE_PEER_ADDRESS=localhost:8051
}

setEnvForPeer0Issuer() {
    export PEER0_ORG2_CA=${PWD}/organizations/peerOrganizations/issuer.asset.com/peers/peer0.issuer.asset.com/tls/ca.crt
    export CORE_PEER_LOCALMSPID=IssuerMSP
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG2_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/issuer.asset.com/users/Admin@issuer.asset.com/msp
    export CORE_PEER_ADDRESS=localhost:9051
}

setEnvForPeer1Issuer() {
    export PEER1_ORG2_CA=${PWD}/organizations/peerOrganizations/issuer.asset.com/peers/peer1.issuer.asset.com/tls/ca.crt
    export CORE_PEER_LOCALMSPID=IssuerMSP
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER1_ORG2_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/issuer.asset.com/users/Admin@issuer.asset.com/msp
    export CORE_PEER_ADDRESS=localhost:10051
}

setEnvForPeer0Agent() {
    export PEER0_ORG3_CA=${PWD}/organizations/peerOrganizations/agent.asset.com/peers/peer0.agent.asset.com/tls/ca.crt
    export CORE_PEER_LOCALMSPID=AgentMSP
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG3_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/agent.asset.com/users/Admin@agent.asset.com/msp
    export CORE_PEER_ADDRESS=localhost:11051
}

setEnvForPeer1Agent() {
    export PEER1_ORG3_CA=${PWD}/organizations/peerOrganizations/agent.asset.com/peers/peer1.agent.asset.com/tls/ca.crt
    export CORE_PEER_LOCALMSPID=AgentMSP
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER1_ORG3_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/agent.asset.com/users/Admin@agent.asset.com/msp
    export CORE_PEER_ADDRESS=localhost:12051
}


setEnvForPeer0Investor() {
    export PEER0_ORG4_CA=${PWD}/organizations/peerOrganizations/investor.asset.com/peers/peer0.investor.asset.com/tls/ca.crt
    export CORE_PEER_LOCALMSPID=InvestorMSP
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG4_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/investor.asset.com/users/Admin@investor.asset.com/msp
    export CORE_PEER_ADDRESS=localhost:13051
}

setEnvForPeer1Investor() {
    export PEER1_ORG4_CA=${PWD}/organizations/peerOrganizations/investor.asset.com/peers/peer1.investor.asset.com/tls/ca.crt
    export CORE_PEER_LOCALMSPID=InvestorMSP
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER1_ORG4_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/investor.asset.com/users/Admin@investor.asset.com/msp
    export CORE_PEER_ADDRESS=localhost:14051
}

createChannel() {
    setEnvForPeer0SysAdmin

    print Green "========== Creating Channel =========="
    echo ""
    peer channel create -o localhost:7050 -c $CHANNEL_NAME \
    --ordererTLSHostnameOverride orderer.asset.com \
    -f ./channel-artifacts/$CHANNEL_NAME.tx --outputBlock \
    ./channel-artifacts/${CHANNEL_NAME}.block \
    --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA 
    echo ""
}

joinChannel() {
    
    setEnvForPeer0SysAdmin
    print Green "========== Peer0SysAdmin Joining Channel '$CHANNEL_NAME' =========="
    peer channel join -b ./channel-artifacts/$CHANNEL_NAME.block
    echo ""

    setEnvForPeer1SysAdmin
    print Green "========== Peer1SysAdmin Joining Channel '$CHANNEL_NAME' =========="
    peer channel join -b ./channel-artifacts/$CHANNEL_NAME.block
    echo ""

    setEnvForPeer0Issuer
    print Green "========== Peer0Issuer Joining Channel '$CHANNEL_NAME' =========="
    peer channel join -b ./channel-artifacts/$CHANNEL_NAME.block
    echo ""

    setEnvForPeer1Issuer
    print Green "========== Peer1Issuer Joining Channel '$CHANNEL_NAME' =========="
    peer channel join -b ./channel-artifacts/$CHANNEL_NAME.block
    echo ""

    setEnvForPeer0Agent
    print Green "========== Peer0Agent Joining Channel '$CHANNEL_NAME' =========="
    peer channel join -b ./channel-artifacts/$CHANNEL_NAME.block
    echo ""

    setEnvForPeer1Agent
    print Green "========== Peer1Agent Joining Channel '$CHANNEL_NAME' =========="
    peer channel join -b ./channel-artifacts/$CHANNEL_NAME.block
    echo ""

    setEnvForPeer0Investor
    print Green "========== Peer0Investor Joining Channel '$CHANNEL_NAME' =========="
    peer channel join -b ./channel-artifacts/$CHANNEL_NAME.block
    echo ""

    setEnvForPeer1Investor
    print Green "========== Peer1Investor Joining Channel '$CHANNEL_NAME' =========="
    peer channel join -b ./channel-artifacts/$CHANNEL_NAME.block
    echo ""
}

updateAnchorPeers() {
    setEnvForPeer0SysAdmin
    print Green "========== Updating Anchor Peer of Peer0SysAdmin =========="
    peer channel update -o localhost:7050 --ordererTLSHostnameOverride orderer.asset.com -c $CHANNEL_NAME -f ./channel-artifacts/${CORE_PEER_LOCALMSPID}Anchor.tx --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA
    echo ""

    setEnvForPeer0Issuer
    print Green "========== Updating Anchor Peer of Peer0Issuer =========="
    peer channel update -o localhost:7050 --ordererTLSHostnameOverride orderer.asset.com -c $CHANNEL_NAME -f ./channel-artifacts/${CORE_PEER_LOCALMSPID}Anchor.tx --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA
    echo ""

    setEnvForPeer0Agent
    print Green "========== Updating Anchor Peer of Peer0Agent =========="
    peer channel update -o localhost:7050 --ordererTLSHostnameOverride orderer.asset.com -c $CHANNEL_NAME -f ./channel-artifacts/${CORE_PEER_LOCALMSPID}Anchor.tx --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA
    echo ""

    setEnvForPeer0Investor
    print Green "========== Updating Anchor Peer of Peer0Investor =========="
    peer channel update -o localhost:7050 --ordererTLSHostnameOverride orderer.asset.com -c $CHANNEL_NAME -f ./channel-artifacts/${CORE_PEER_LOCALMSPID}Anchor.tx --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA
    echo ""
}

createChannel
joinChannel
updateAnchorPeers