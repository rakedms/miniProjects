const express = require('express');
const ABI = require('./ABI.js');
const ethers = require('ethers');
const app = express();
const contractAddress = '0xA6D63e42EE16b72D411Ce6a88836187aa06759FC';


app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Connect to contract
const provider = new ethers.providers.JsonRpcProvider('https://sepolia.infura.io/v3/df3074c5878c41ffadad5040d7b08329');
console.log("Provider Connected");

// const contract = new ethers.Contract(contractAddress, ABI, provider);
// console.log("Contract Connected");

// const wallet = new ethers.Wallet(privateKey, provider);
// console.log("Wallet Connected");

// await contract.connect(wallet).transfer(FromAddress,Qty,ToAddress).then(()=>{
//     let status= "Success"
//     res.redirect(`/?transferedStatus=${status}`)
// })

// Example route to get details of a land by its ID
app.post('/land/:privatekey', async (req, res) => {
    try{
        const privateKey = req.params.privatekey;
        const contract = new ethers.Contract(contractAddress, ABI, provider);
        const wallet = new ethers.Wallet(privateKey, provider);
        const {area, city, state, price, surveynumber, document} = req.body;

        const response = contract.connect(wallet).addLand(area, city, state, price, surveynumber, document)
        console.log("Transaction submitted");

        return response;

    }catch(error){
        console.log(error);
        return(error)
    }
});

app.post('/addLandInspector/:privatekey', async (req, res) => {
    try{
        const privateKey = req.params.privatekey;
        const contract = new ethers.Contract(contractAddress, ABI, provider);
        const wallet = new ethers.Wallet(privateKey, provider);
        const {Land_Inspector_Address} = req.body;

        const response = contract.connect(wallet).assignLandInspector(Land_Inspector_Address)
        console.log("Transaction submitted");

        return response;

    }catch(error){
        console.log(error);
        return(error)
    }
});


app.post('/addBalanceTo/:privatekey', async (req, res) => {
    try{
        const privateKey = req.params.privatekey;
        const contract = new ethers.Contract(contractAddress, ABI, provider);
        const wallet = new ethers.Wallet(privateKey, provider);
        const {ToAddress, amount} = req.body;

        const response = contract.connect(wallet).addBalanceTo(ToAddress, amount)
        console.log("Transaction submitted");

        return response;

    }catch(error){
        console.log(error);
        return(error)
    }
});

app.post('/verifyLand/:privatekey', async (req, res) => {
    try{
        const privateKey = req.params.privatekey;
        const contract = new ethers.Contract(contractAddress, ABI, provider);
        const wallet = new ethers.Wallet(privateKey, provider);
        const {amount} = req.body;

        const response = contract.connect(wallet).verifyLand(amount)
        console.log("Transaction submitted");

        return response;

    }catch(error){
        console.log(error);
        return(error)
    }
});

app.put('/requestLand/:privatekey', async (req, res) => {
    try{
        const privateKey = req.params.privatekey;
        const contract = new ethers.Contract(contractAddress, ABI, provider);
        const wallet = new ethers.Wallet(privateKey, provider);
        const {LandId} = req.body;

        const response = contract.connect(wallet).requestLand(LandId)
        console.log("Transaction submitted");

        return response;

    }catch(error){
        console.log(error);
        return(error)
    }
});

app.post('/approveRequestByOwner/:privatekey', async (req, res) => {
    try{
        const privateKey = req.params.privatekey;
        const contract = new ethers.Contract(contractAddress, ABI, provider);
        const wallet = new ethers.Wallet(privateKey, provider);
        const {id, buyer} = req.body;

        const response = contract.connect(wallet).approveRequestByOwner(id, buyer)
        console.log("Transaction submitted");

        return response;

    }catch(error){
        console.log(error);
        return(error)
    }
});

app.post('/approveRequestByOwner/:privatekey', async (req, res) => {
    try{
        const privateKey = req.params.privatekey;
        const contract = new ethers.Contract(contractAddress, ABI, provider);
        const wallet = new ethers.Wallet(privateKey, provider);
        const {id, buyer} = req.body;

        const response = contract.connect(wallet).approveRequestByOwner(id, buyer)
        console.log("Transaction submitted");

        return response;

    }catch(error){
        console.log(error);
        return(error)
    }
});

app.post('/getAllowance/:privatekey', async (req, res) => {
    try{
        const privateKey = req.params.privatekey;
        const contract = new ethers.Contract(contractAddress, ABI, provider);
        const wallet = new ethers.Wallet(privateKey, provider);
        const {fromAddress, amt} = req.body;

        const response = contract.connect(wallet).getAllowance(fromAddress, amt)
        console.log("Transaction submitted");

        return response;

    }catch(error){
        console.log(error);
        return(error)
    }
});

app.post('/transferLandOwnership/:privatekey', async (req, res) => {
    try{
        const privateKey = req.params.privatekey;
        const contract = new ethers.Contract(contractAddress, ABI, provider);
        const wallet = new ethers.Wallet(privateKey, provider);
        const {id, newOwner} = req.body;

        const response = contract.connect(wallet).transferLandOwnership(id, newOwner)
        console.log("Transaction submitted");

        return response;

    }catch(error){
        console.log(error);
        return(error)
    }
});

app.get('/getLandDetails/:privatekey', async (req, res) => {
    try{
        const privateKey = req.params.privatekey;
        const contract = new ethers.Contract(contractAddress, ABI, provider);
        const wallet = new ethers.Wallet(privateKey, provider);
        const {id} = req.body;

        const response = contract.connect(wallet).getLandDetails(id)
        console.log("Transaction submitted");

        return response;

    }catch(error){
        console.log(error);
        return(error)
    }
});


// Example route to request a land



const server = app.listen(8000);
console.log(`server started in ${server.address().port}`);







