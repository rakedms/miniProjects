require("@nomicfoundation/hardhat-toolbox");

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: "0.8.20",
  networks:{
    test:{
      url: "http://localhost:8545/",
      accounts: ["4762e04d10832808a0aebdaa79c12de54afbe006bfffd228b3abcc494fe986f9"]
    }
  }
};
