// test/LandRegistration.test.js
const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("LandRegistration Contract", function () {
  let LANDToken;
  let landToken;
  let LandRegistration;
  let landRegistration;
  let landInspector;
  let owner;
  let user1;
  let user2;

  beforeEach(async function () {
    [landInspector, owner, user1, user2] = await ethers.getSigners();
  
    // LANDToken = await ethers.getContractFactory("LANDToken");
    // landToken = await LANDToken.connect(landInspector).deploy();

    landToken = await ethers.deployContract("LANDToken", [], { from: landInspector.address });
    await landToken.waitForDeployment();
  
    // LandRegistration = await ethers.getContractFactory("LandRegistration");
    // landRegistration = await LandRegistration.deploy(landToken.target);

    landRegistration = await ethers.deployContract("LandRegistration", [landToken.target]);
    await landRegistration.waitForDeployment();
  
    // Transfer tokens from landInspector to user1 and user2
    await landToken.connect(landInspector).transfer(user1.address, ethers.parseEther("100000"));
    await landToken.connect(landInspector).transfer(user2.address, ethers.parseEther("100000"));
  });
  
  

  describe("Land Registration", function () {
    it("Should add a new land", async function () {
      await landRegistration.addLand(100, "City", "State", 1000, "123", "Document");
      const landDetails = await landRegistration.getLandDetails(1);
      expect(landDetails[0]).to.equal(100); // Check area
      expect(landDetails[1]).to.equal("City"); // Check city
      expect(landDetails[2]).to.equal("State"); // Check state
      expect(landDetails[3]).to.equal(1000); // Check price
      expect(landDetails[4]).to.equal("123"); // Check surveyNumber
      expect(landDetails[5]).to.equal("Document"); // Check document
      expect(landDetails[6]).to.equal(false);
      expect(landDetails[7]).to.equal(landInspector.address); // Check owner dynamically
    });
    

    it("Should allow Land Inspector to verify land", async function () {
      await landRegistration.connect(user1).addLand(100, "City", "State", 1000, "123", "Document");
      await landRegistration.connect(landInspector).assignLandInspector(landInspector.address);
      await landRegistration.connect(landInspector).verifyLand(1);
      const landDetails = await landRegistration.getLandDetails(1);
      expect(landDetails[6]).to.equal(true); 
    });

    it("Should allow user to request land", async function () {
      await landRegistration.connect(user1).addLand(100, "City", "State", 1000, "123", "Document");
      await landRegistration.connect(user2).requestLand(1);
      const landDetails = await landRegistration.getLandDetails(1);
      expect(landDetails[8][0]).to.equal(user2.address);
    });

    it("Should allow owner to approve land request", async function () {
      await landRegistration.connect(user1).addLand(100, "City", "State", 1000, "123", "Document");
      await landRegistration.connect(user2).requestLand(1);
      await landRegistration.connect(user1).approveRequestByOwner(1, user2.address);
      const approvedBuyer = await landRegistration.approvedBuyer(1);
      expect(approvedBuyer).to.equal(user2.address); 
    });

    it("Should add owner address correctly", async function () {
      await landRegistration.connect(user1).addLand(100, "City", "State", 1000, "123", "Document");
      const addedLandDetails = await landRegistration.connect(user1).getLandDetails(1);
      expect(addedLandDetails[7]).to.equal(user1.address);
    })  

    it("Should add owner address correctly", async function () {
      await landRegistration.connect(user1).addLand(100, "City", "State", 1000, "123", "Document");
      const addedLandDetails = await landRegistration.connect(user1).getLandDetails(1);
      expect(addedLandDetails[7]).to.equal(user1.address);
    })     


    it("Should allow Land Inspector to transfer land ownership", async function () {
      await landRegistration.connect(user1).addLand(100, "City", "State", 1000, "123", "Document");
      await landRegistration.connect(landInspector).assignLandInspector(landInspector.address);
      await landRegistration.connect(landInspector).verifyLand(1);
      await landRegistration.connect(user2).requestLand(1);
      await landRegistration.connect(user1).approveRequestByOwner(1, user2.address);
      // await landRegistration.connect(user2).getAllowance(landRegistration.target, 1000);
      console.log("before", await landToken.allowance(user2.address, landRegistration.target))
      
      await landToken.connect(user2).approve(landRegistration.target, 1000)
      console.log("after", await landToken.allowance(user2.address, landRegistration.target))
      await landRegistration.connect(landInspector).transferLandOwnership(1, user2.address);
      const landDetails = await landRegistration.getLandDetails(1);
      console.log(landDetails[7], user2.address)

      expect(landDetails[7]).to.equal(user2.address); 
    });
  });
});
