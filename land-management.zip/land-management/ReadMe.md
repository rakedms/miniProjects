Contract Address (LANDToken) : 0xE1710a5303c7C4339C52Cf261b29830b1416FA6c
Contract Address (LandRegisration) : 0xA6D63e42EE16b72D411Ce6a88836187aa06759FC   


There is no front end, 
I have used individual private keys of the wallet to submit transaction, since there is no front end, we can't connect metamask